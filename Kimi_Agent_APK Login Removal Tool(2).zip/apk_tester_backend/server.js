const express = require('express');
const multer = require('multer');
const cors = require('cors');
const { exec, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Create uploads directory
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/vnd.android.package-archive' || 
        file.originalname.endsWith('.apk')) {
      cb(null, true);
    } else {
      cb(new Error('Only APK files are allowed!'));
    }
  },
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB limit
});

// Store analysis results
const analysisResults = new Map();

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Check if tools are installed
app.get('/api/check-tools', (req, res) => {
  const tools = ['apktool', 'python3', 'adb'];
  const results = {};
  
  let checked = 0;
  tools.forEach(tool => {
    exec(`which ${tool}`, (error, stdout) => {
      results[tool] = !error && stdout.trim() !== '';
      checked++;
      if (checked === tools.length) {
        res.json({ tools: results, allInstalled: Object.values(results).every(v => v) });
      }
    });
  });
});

// Upload and analyze APK
app.post('/api/analyze', upload.single('apk'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No APK file uploaded' });
  }

  const apkPath = req.file.path;
  const analysisId = path.basename(req.file.filename, path.extname(req.file.filename));
  
  console.log(`[${analysisId}] Starting analysis for: ${req.file.originalname}`);
  
  // Initialize result
  analysisResults.set(analysisId, {
    id: analysisId,
    filename: req.file.originalname,
    status: 'analyzing',
    progress: 0,
    logs: [],
    vulnerabilities: [],
    bypassMethods: [],
    report: null,
    startedAt: new Date().toISOString()
  });

  // Start analysis in background
  runAnalysis(analysisId, apkPath);
  
  res.json({ 
    analysisId, 
    message: 'Analysis started',
    status: 'analyzing'
  });
});

// Get analysis status
app.get('/api/analysis/:id', (req, res) => {
  const result = analysisResults.get(req.params.id);
  if (!result) {
    return res.status(404).json({ error: 'Analysis not found' });
  }
  res.json(result);
});

// Get all analyses
app.get('/api/analyses', (req, res) => {
  const analyses = Array.from(analysisResults.values()).map(a => ({
    id: a.id,
    filename: a.filename,
    status: a.status,
    progress: a.progress,
    startedAt: a.startedAt
  }));
  res.json(analyses);
});

// Delete analysis
app.delete('/api/analysis/:id', (req, res) => {
  const result = analysisResults.get(req.params.id);
  if (result) {
    // Clean up files
    try {
      if (fs.existsSync(result.apkPath)) {
        fs.unlinkSync(result.apkPath);
      }
      const workDir = path.join(__dirname, 'uploads', `work_${req.params.id}`);
      if (fs.existsSync(workDir)) {
        fs.rmSync(workDir, { recursive: true });
      }
    } catch (e) {
      console.error('Cleanup error:', e);
    }
    analysisResults.delete(req.params.id);
  }
  res.json({ message: 'Analysis deleted' });
});

// Run analysis function
async function runAnalysis(analysisId, apkPath) {
  const result = analysisResults.get(analysisId);
  const workDir = path.join(__dirname, 'uploads', `work_${analysisId}`);
  
  result.apkPath = apkPath;
  result.workDir = workDir;
  
  const updateProgress = (progress, log) => {
    result.progress = progress;
    if (log) {
      result.logs.push({ time: new Date().toISOString(), message: log });
      console.log(`[${analysisId}] ${log}`);
    }
  };
  
  try {
    // Step 1: Check APK file
    updateProgress(5, 'Validating APK file...');
    await sleep(500);
    
    if (!fs.existsSync(apkPath)) {
      throw new Error('APK file not found');
    }
    
    const stats = fs.statSync(apkPath);
    updateProgress(10, `APK size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
    
    // Step 2: Decompile APK
    updateProgress(15, 'Decompiling APK...');
    await runApkTool('d', ['-f', '-o', workDir, apkPath], updateProgress, 15, 40);
    
    // Step 3: Analyze AndroidManifest.xml
    updateProgress(40, 'Analyzing AndroidManifest.xml...');
    await analyzeManifest(analysisId, workDir);
    
    // Step 4: Scan smali code
    updateProgress(50, 'Scanning smali code for vulnerabilities...');
    await scanSmali(analysisId, workDir);
    
    // Step 5: Check for hardcoded credentials
    updateProgress(70, 'Checking for hardcoded credentials...');
    await checkHardcodedCreds(analysisId, workDir);
    
    // Step 6: Generate bypass methods
    updateProgress(80, 'Generating bypass methods...');
    generateBypassMethods(analysisId);
    
    // Step 7: Generate report
    updateProgress(90, 'Generating security report...');
    await generateReport(analysisId);
    
    updateProgress(100, 'Analysis complete!');
    result.status = 'completed';
    result.completedAt = new Date().toISOString();
    
  } catch (error) {
    console.error(`[${analysisId}] Analysis error:`, error);
    result.status = 'error';
    result.error = error.message;
    result.logs.push({ time: new Date().toISOString(), message: `Error: ${error.message}` });
  }
}

// Run apktool command
function runApkTool(command, args, updateProgress, startProgress, endProgress) {
  return new Promise((resolve, reject) => {
    const child = spawn('apktool', [command, ...args]);
    
    child.stdout.on('data', (data) => {
      const output = data.toString().trim();
      if (output) {
        updateProgress(startProgress + (endProgress - startProgress) * 0.5, output);
      }
    });
    
    child.stderr.on('data', (data) => {
      const output = data.toString().trim();
      if (output && !output.includes('WARNING')) {
        updateProgress(startProgress + (endProgress - startProgress) * 0.5, output);
      }
    });
    
    child.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`APKTool failed with code ${code}`));
      }
    });
    
    child.on('error', (err) => {
      reject(err);
    });
  });
}

// Analyze AndroidManifest.xml
async function analyzeManifest(analysisId, workDir) {
  const result = analysisResults.get(analysisId);
  const manifestPath = path.join(workDir, 'AndroidManifest.xml');
  
  if (!fs.existsSync(manifestPath)) {
    result.logs.push({ time: new Date().toISOString(), message: 'AndroidManifest.xml not found' });
    return;
  }
  
  const manifest = fs.readFileSync(manifestPath, 'utf8');
  
  // Extract package name
  const packageMatch = manifest.match(/package="([^"]+)"/);
  if (packageMatch) {
    result.packageName = packageMatch[1];
  }
  
  // Check for debug mode
  if (manifest.includes('android:debuggable="true"')) {
    result.vulnerabilities.push({
      name: 'Debug Mode Enabled',
      severity: 'medium',
      description: 'App can be debugged',
      location: 'AndroidManifest.xml'
    });
  }
  
  // Check for allowBackup
  if (manifest.includes('android:allowBackup="true"')) {
    result.vulnerabilities.push({
      name: 'Allow Backup Enabled',
      severity: 'medium',
      description: 'App data can be backed up and extracted',
      location: 'AndroidManifest.xml'
    });
  }
  
  // Find activities
  const activityMatches = manifest.matchAll(/<activity[^>]*android:name="([^"]+)"/g);
  result.activities = Array.from(activityMatches).map(m => m[1]);
  
  // Find main activity
  const mainActivityMatch = manifest.match(/<activity[^>]*>[\s\S]*?<intent-filter>[\s\S]*?MAIN[\s\S]*?<\/intent-filter>[\s\S]*?<\/activity>/);
  if (mainActivityMatch) {
    const nameMatch = mainActivityMatch[0].match(/android:name="([^"]+)"/);
    if (nameMatch) {
      result.mainActivity = nameMatch[1];
    }
  }
}

// Scan smali code
async function scanSmali(analysisId, workDir) {
  const result = analysisResults.get(analysisId);
  const smaliDir = path.join(workDir, 'smali');
  
  if (!fs.existsSync(smaliDir)) {
    result.logs.push({ time: new Date().toISOString(), message: 'Smali directory not found' });
    return;
  }
  
  const patterns = [
    { pattern: /login|signin|authenticate/i, name: 'Login-related code' },
    { pattern: /password|passwd|pwd/i, name: 'Password handling' },
    { pattern: /getSharedPreferences|SharedPreferences/i, name: 'SharedPreferences usage' },
    { pattern: /if-eqz|if-nez/i, name: 'Conditional checks' }
  ];
  
  const findings = [];
  
  function scanDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const filepath = path.join(dir, file);
      const stat = fs.statSync(filepath);
      
      if (stat.isDirectory()) {
        scanDir(filepath);
      } else if (file.endsWith('.smali')) {
        const content = fs.readFileSync(filepath, 'utf8');
        
        for (const { pattern, name } of patterns) {
          if (pattern.test(content)) {
            findings.push({
              file: path.relative(workDir, filepath),
              type: name,
              snippet: content.substring(0, 200)
            });
          }
        }
      }
    }
  }
  
  scanDir(smaliDir);
  result.smaliFindings = findings.slice(0, 20);
  
  // Check for local authentication
  if (findings.some(f => f.type === 'SharedPreferences usage' && 
      findings.some(f2 => f2.type === 'Login-related code'))) {
    result.vulnerabilities.push({
      name: 'Local Authentication Detected',
      severity: 'high',
      description: 'Login state may be stored locally and can be modified',
      location: 'Smali code'
    });
  }
}

// Check for hardcoded credentials
async function checkHardcodedCreds(analysisId, workDir) {
  const result = analysisResults.get(analysisId);
  const smaliDir = path.join(workDir, 'smali');
  
  if (!fs.existsSync(smaliDir)) return;
  
  const credPatterns = [
    /const-string[^,]+,\s*"(admin|password|123456|test|root)"/i,
    /const-string[^,]+,\s*"[a-z]+@[a-z]+\.com"/i
  ];
  
  const hardcoded = [];
  
  function scanDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const filepath = path.join(dir, file);
      const stat = fs.statSync(filepath);
      
      if (stat.isDirectory()) {
        scanDir(filepath);
      } else if (file.endsWith('.smali')) {
        const content = fs.readFileSync(filepath, 'utf8');
        const lines = content.split('\n');
        
        lines.forEach((line, idx) => {
          for (const pattern of credPatterns) {
            const match = line.match(pattern);
            if (match) {
              hardcoded.push({
                file: path.relative(workDir, filepath),
                line: idx + 1,
                value: match[1]
              });
            }
          }
        });
      }
    }
  }
  
  scanDir(smaliDir);
  result.hardcodedCredentials = hardcoded;
  
  if (hardcoded.length > 0) {
    result.vulnerabilities.push({
      name: 'Potential Hardcoded Credentials',
      severity: 'critical',
      description: `Found ${hardcoded.length} potential hardcoded credentials`,
      location: 'Smali code',
      details: hardcoded
    });
  }
}

// Generate bypass methods
function generateBypassMethods(analysisId) {
  const result = analysisResults.get(analysisId);
  const methods = [];
  
  // Method 1: Direct activity launch
  if (result.mainActivity) {
    methods.push({
      title: 'Direct Activity Launch',
      difficulty: 'Very Easy',
      description: 'Launch main activity directly without login',
      command: `adb shell am start -n ${result.packageName || 'com.example'}/${result.mainActivity}`,
      steps: [
        'Connect device or start emulator',
        `Run: adb shell am start -n ${result.packageName || 'com.example'}/${result.mainActivity}`,
        'Check if main screen opens without login'
      ]
    });
  }
  
  // Method 2: SharedPreferences modification
  if (result.vulnerabilities.some(v => v.name.includes('Local Authentication'))) {
    methods.push({
      title: 'SharedPreferences Modification',
      difficulty: 'Medium',
      description: 'Modify local storage to fake logged-in state',
      steps: [
        'Root the device or use emulator',
        `Navigate to: /data/data/${result.packageName || 'com.example'}/shared_prefs/`,
        'Find preferences XML file',
        'Change is_logged_in or similar flag to true',
        'Restart app'
      ]
    });
  }
  
  // Method 3: Smali modification
  methods.push({
    title: 'Smali Code Modification',
    difficulty: 'Hard',
    description: 'Modify login check in decompiled code',
    steps: [
      `Decompile APK: apktool d ${result.filename} -o output`,
      'Find LoginActivity.smali or similar',
      'Locate if-eqz or if-nez condition for login',
      'Flip the condition or replace with nop',
      'Recompile: apktool b output -o mod.apk',
      'Sign and install the modified APK'
    ]
  });
  
  // Method 4: Manifest modification
  methods.push({
    title: 'Manifest Modification',
    difficulty: 'Medium',
    description: 'Disable login activity in AndroidManifest.xml',
    steps: [
      `Decompile APK: apktool d ${result.filename} -o output`,
      'Open AndroidManifest.xml',
      'Find LoginActivity',
      'Add android:enabled="false" OR remove intent-filter',
      'Set MainActivity as launcher',
      'Recompile and sign'
    ]
  });
  
  result.bypassMethods = methods;
}

// Generate report
async function generateReport(analysisId) {
  const result = analysisResults.get(analysisId);
  
  const report = {
    summary: {
      filename: result.filename,
      packageName: result.packageName,
      status: result.status,
      vulnerabilitiesFound: result.vulnerabilities.length,
      critical: result.vulnerabilities.filter(v => v.severity === 'critical').length,
      high: result.vulnerabilities.filter(v => v.severity === 'high').length,
      medium: result.vulnerabilities.filter(v => v.severity === 'medium').length,
      low: result.vulnerabilities.filter(v => v.severity === 'low').length
    },
    vulnerabilities: result.vulnerabilities,
    bypassMethods: result.bypassMethods,
    activities: result.activities || [],
    mainActivity: result.mainActivity,
    hardcodedCredentials: result.hardcodedCredentials || [],
    smaliFindings: result.smaliFindings || [],
    generatedAt: new Date().toISOString()
  };
  
  result.report = report;
  
  // Save report to file
  const reportPath = path.join(__dirname, 'uploads', `report_${analysisId}.json`);
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
}

// Helper: Sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║           APK Security Tester Server                         ║
║           Running on http://localhost:${PORT}                    ║
╚══════════════════════════════════════════════════════════════╝

API Endpoints:
  POST /api/analyze     - Upload and analyze APK
  GET  /api/analysis/:id - Get analysis status
  GET  /api/health      - Health check
  GET  /api/check-tools - Check installed tools

Upload directory: ${uploadsDir}
  `);
});

import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Shield, 
  Unlock, 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Play,
  Upload,
  Code,
  Smartphone,
  RefreshCw,
  FileCheck
} from 'lucide-react';
import { toast } from 'sonner';

const API_BASE = '';

// Types
interface Analysis {
  id: string;
  filename: string;
  status: 'analyzing' | 'completed' | 'error';
  progress: number;
  logs: { time: string; message: string }[];
  vulnerabilities: Vulnerability[];
  bypassMethods: BypassMethod[];
  report: Report | null;
  error?: string;
}

interface Vulnerability {
  name: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  location: string;
  details?: any;
}

interface BypassMethod {
  title: string;
  difficulty: string;
  description: string;
  command?: string;
  steps: string[];
}

interface Report {
  summary: {
    filename: string;
    packageName: string;
    vulnerabilitiesFound: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  vulnerabilities: Vulnerability[];
  bypassMethods: BypassMethod[];
  activities: string[];
  mainActivity: string;
}

// APK Upload Component
function APKUploader({ onAnalysisStart }: { onAnalysisStart: (id: string) => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.name.endsWith('.apk')) {
        setFile(droppedFile);
      } else {
        toast.error('Please upload an APK file');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const uploadFile = async () => {
    if (!file) return;
    
    setUploading(true);
    const formData = new FormData();
    formData.append('apk', file);
    
    try {
      const response = await fetch(`${API_BASE}/api/analyze`, {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      
      if (response.ok) {
        toast.success('Analysis started!');
        onAnalysisStart(data.analysisId);
        setFile(null);
      } else {
        toast.error(data.error || 'Upload failed');
      }
    } catch (error) {
      toast.error('Network error. Is the server running?');
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5" />
          Upload APK for Analysis
        </CardTitle>
        <CardDescription>
          Apni APK upload karo aur security analysis shuru karo
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
            <Smartphone className="w-8 h-8 text-white" />
          </div>
          
          {file ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-green-600">
                <FileCheck className="w-5 h-5" />
                <span className="font-semibold">{file.name}</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Size: {(file.size / 1024 / 1024).toFixed(2)} MB
              </p>
              <div className="flex gap-2 justify-center">
                <Button onClick={() => setFile(null)} variant="outline">
                  Change File
                </Button>
                <Button onClick={uploadFile} disabled={uploading} className="gap-2">
                  {uploading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                  {uploading ? 'Uploading...' : 'Start Analysis'}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-lg font-medium">Drag & drop your APK here</p>
              <p className="text-sm text-muted-foreground">or click to browse</p>
              <Input
                type="file"
                accept=".apk"
                onChange={handleFileChange}
                className="hidden"
                id="apk-input"
              />
              <Button asChild variant="outline">
                <label htmlFor="apk-input" className="cursor-pointer">
                  Browse Files
                </label>
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Analysis Progress Component
function AnalysisProgress({ analysis }: { analysis: Analysis }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'error': return 'text-red-600';
      case 'analyzing': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Analysis Progress
          </span>
          <Badge variant={analysis.status === 'completed' ? 'default' : 'secondary'}>
            {analysis.status}
          </Badge>
        </CardTitle>
        <CardDescription>
          {analysis.filename}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Progress value={analysis.progress} className="h-2" />
        
        <div className="flex justify-between text-sm">
          <span className={getStatusColor(analysis.status)}>
            {analysis.progress}% Complete
          </span>
          <span className="text-muted-foreground">
            {analysis.logs.length} log entries
          </span>
        </div>
        
        {analysis.status === 'analyzing' && (
          <div className="flex items-center gap-2 text-blue-600">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span className="text-sm">Analyzing...</span>
          </div>
        )}
        
        {analysis.error && (
          <Alert variant="destructive">
            <AlertTriangle className="w-4 h-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{analysis.error}</AlertDescription>
          </Alert>
        )}
        
        <ScrollArea className="h-48 border rounded-lg p-4 bg-slate-950">
          <div className="space-y-1 font-mono text-sm">
            {analysis.logs.map((log, i) => (
              <div key={i} className="text-green-400">
                <span className="text-gray-500">[{new Date(log.time).toLocaleTimeString()}]</span>{' '}
                {log.message}
              </div>
            ))}
            {analysis.logs.length === 0 && (
              <div className="text-gray-500">Waiting to start...</div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

// Vulnerabilities Component
function VulnerabilitiesList({ vulnerabilities }: { vulnerabilities: Vulnerability[] }) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getBadgeVariant = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'secondary';
      case 'medium': return 'default';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  if (vulnerabilities.length === 0) {
    return (
      <Alert>
        <CheckCircle className="w-4 h-4" />
        <AlertTitle>No Vulnerabilities Found</AlertTitle>
        <AlertDescription>
          Great! No obvious vulnerabilities were detected in this APK.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-red-600">
              {vulnerabilities.filter(v => v.severity === 'critical').length}
            </p>
            <p className="text-sm text-red-700">Critical</p>
          </CardContent>
        </Card>
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-orange-600">
              {vulnerabilities.filter(v => v.severity === 'high').length}
            </p>
            <p className="text-sm text-orange-700">High</p>
          </CardContent>
        </Card>
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-yellow-600">
              {vulnerabilities.filter(v => v.severity === 'medium').length}
            </p>
            <p className="text-sm text-yellow-700">Medium</p>
          </CardContent>
        </Card>
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-green-600">
              {vulnerabilities.filter(v => v.severity === 'low').length}
            </p>
            <p className="text-sm text-green-700">Low</p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        {vulnerabilities.map((vuln, i) => (
          <Card key={i} className="overflow-hidden">
            <div className={`h-1 ${getSeverityColor(vuln.severity)}`} />
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold">{vuln.name}</h4>
                    <Badge variant={getBadgeVariant(vuln.severity)}>
                      {vuln.severity}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{vuln.description}</p>
                  <p className="text-xs text-gray-500">Location: {vuln.location}</p>
                  
                  {vuln.details && (
                    <div className="mt-3 p-2 bg-slate-100 rounded text-xs font-mono overflow-x-auto">
                      <pre>{JSON.stringify(vuln.details, null, 2)}</pre>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// Bypass Methods Component
function BypassMethodsList({ methods }: { methods: BypassMethod[] }) {
  const getDifficultyColor = (diff: string) => {
    switch (diff.toLowerCase()) {
      case 'very easy': return 'text-green-600';
      case 'easy': return 'text-green-500';
      case 'medium': return 'text-yellow-600';
      case 'hard': return 'text-orange-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-4">
      {methods.map((method, i) => (
        <Card key={i}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Unlock className="w-5 h-5 text-red-500" />
                {method.title}
              </CardTitle>
              <span className={`text-sm font-semibold ${getDifficultyColor(method.difficulty)}`}>
                {method.difficulty}
              </span>
            </div>
            <CardDescription>{method.description}</CardDescription>
          </CardHeader>
          <CardContent>
            {method.command && (
              <div className="mb-4">
                <p className="text-sm font-semibold mb-1">Command:</p>
                <div className="bg-slate-900 text-green-400 p-3 rounded-lg font-mono text-sm overflow-x-auto">
                  {method.command}
                </div>
              </div>
            )}
            
            <div>
              <p className="text-sm font-semibold mb-2">Steps:</p>
              <ol className="space-y-2">
                {method.steps.map((step, j) => (
                  <li key={j} className="flex gap-2 text-sm">
                    <span className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-semibold shrink-0">
                      {j + 1}
                    </span>
                    <span className="text-muted-foreground">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// Report Summary Component
function ReportSummary({ report }: { report: Report }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileCheck className="w-5 h-5" />
          Analysis Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-muted-foreground">Package Name</p>
            <p className="font-mono text-sm">{report.summary.packageName || 'N/A'}</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-muted-foreground">Main Activity</p>
            <p className="font-mono text-sm">{report.mainActivity || 'N/A'}</p>
          </div>
        </div>
        
        <Separator />
        
        <div>
          <p className="text-sm font-semibold mb-2">Activities Found ({report.activities?.length || 0}):</p>
          <ScrollArea className="h-32 border rounded-lg p-2">
            <div className="space-y-1">
              {report.activities?.map((activity, i) => (
                <div key={i} className="text-xs font-mono text-muted-foreground">
                  {activity}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
        
        <Separator />
        
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="p-2 bg-red-50 rounded">
            <p className="text-xl font-bold text-red-600">{report.summary.critical}</p>
            <p className="text-xs text-red-700">Critical</p>
          </div>
          <div className="p-2 bg-orange-50 rounded">
            <p className="text-xl font-bold text-orange-600">{report.summary.high}</p>
            <p className="text-xs text-orange-700">High</p>
          </div>
          <div className="p-2 bg-yellow-50 rounded">
            <p className="text-xl font-bold text-yellow-600">{report.summary.medium}</p>
            <p className="text-xs text-yellow-700">Medium</p>
          </div>
          <div className="p-2 bg-green-50 rounded">
            <p className="text-xl font-bold text-green-600">{report.summary.low}</p>
            <p className="text-xs text-green-700">Low</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Main App Component
function App() {
  const [currentAnalysisId, setCurrentAnalysisId] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [serverStatus, setServerStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [toolsInstalled, setToolsInstalled] = useState(false);

  // Check server health
  useEffect(() => {
    checkServerHealth();
  }, []);

  const checkServerHealth = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/health`);
      if (response.ok) {
        setServerStatus('online');
        checkTools();
      } else {
        setServerStatus('offline');
      }
    } catch {
      setServerStatus('offline');
    }
  };

  const checkTools = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/check-tools`);
      const data = await response.json();
      setToolsInstalled(data.allInstalled);
    } catch {
      setToolsInstalled(false);
    }
  };

  // Poll for analysis updates
  useEffect(() => {
    if (!currentAnalysisId) return;

    const pollInterval = setInterval(async () => {
      try {
        const response = await fetch(`${API_BASE}/api/analysis/${currentAnalysisId}`);
        if (response.ok) {
          const data = await response.json();
          setAnalysis(data);
          
          if (data.status === 'completed' || data.status === 'error') {
            clearInterval(pollInterval);
          }
        }
      } catch (error) {
        console.error('Poll error:', error);
      }
    }, 1000);

    return () => clearInterval(pollInterval);
  }, [currentAnalysisId]);

  const handleAnalysisStart = (id: string) => {
    setCurrentAnalysisId(id);
    setAnalysis(null);
  };

  const resetAnalysis = () => {
    setCurrentAnalysisId(null);
    setAnalysis(null);
  };

  if (serverStatus === 'offline') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <XCircle className="w-6 h-6" />
              Server Offline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              Backend server is not running. Please start it first:
            </p>
            <div className="bg-slate-900 text-green-400 p-3 rounded-lg font-mono text-sm">
              <p>cd /mnt/okcomputer/output/apk_tester_backend</p>
              <p>node server.js</p>
            </div>
            <Button onClick={checkServerHealth} className="w-full mt-4 gap-2">
              <RefreshCw className="w-4 h-4" />
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-slate-900 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">APK Security Tester</h1>
                <p className="text-sm text-slate-400">Real APK Analysis Tool</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={toolsInstalled ? 'default' : 'destructive'} className="gap-1">
                {toolsInstalled ? <CheckCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                Tools {toolsInstalled ? 'OK' : 'Missing'}
              </Badge>
              <Badge variant="secondary" className="gap-1">
                <Code className="w-3 h-3" />
                v1.0
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Warning Alert */}
        <Alert className="mb-6 border-amber-500 bg-amber-50">
          <AlertTriangle className="w-4 h-4 text-amber-600" />
          <AlertTitle className="text-amber-800">Important Notice</AlertTitle>
          <AlertDescription className="text-amber-700">
            Ye tool <strong>SIRF aapki khud ki APKs test karne ke liye hai</strong>. 
            Kisi aur ki apps par use karna illegal hai!
          </AlertDescription>
        </Alert>

        {!currentAnalysisId ? (
          <APKUploader onAnalysisStart={handleAnalysisStart} />
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Analysis: {analysis?.filename}</h2>
              <Button onClick={resetAnalysis} variant="outline" className="gap-2">
                <Upload className="w-4 h-4" />
                New Analysis
              </Button>
            </div>

            {analysis && (
              <Tabs defaultValue="progress" className="space-y-6">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
                  <TabsTrigger value="progress">Progress</TabsTrigger>
                  <TabsTrigger value="summary" disabled={!analysis.report}>Summary</TabsTrigger>
                  <TabsTrigger value="vulns" disabled={analysis.vulnerabilities.length === 0}>Vulnerabilities</TabsTrigger>
                  <TabsTrigger value="bypass" disabled={analysis.bypassMethods.length === 0}>Bypass Methods</TabsTrigger>
                  <TabsTrigger value="logs">Logs</TabsTrigger>
                </TabsList>

                <TabsContent value="progress">
                  <AnalysisProgress analysis={analysis} />
                </TabsContent>

                <TabsContent value="summary">
                  {analysis.report && <ReportSummary report={analysis.report} />}
                </TabsContent>

                <TabsContent value="vulns">
                  <VulnerabilitiesList vulnerabilities={analysis.vulnerabilities} />
                </TabsContent>

                <TabsContent value="bypass">
                  <BypassMethodsList methods={analysis.bypassMethods} />
                </TabsContent>

                <TabsContent value="logs">
                  <Card>
                    <CardHeader>
                      <CardTitle>Analysis Logs</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-96 border rounded-lg p-4 bg-slate-950">
                        <div className="space-y-1 font-mono text-sm">
                          {analysis.logs.map((log, i) => (
                            <div key={i} className="text-green-400">
                              <span className="text-gray-500">[{new Date(log.time).toLocaleTimeString()}]</span>{' '}
                              {log.message}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            )}
          </div>
        )}

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t text-center text-muted-foreground">
          <p className="flex items-center justify-center gap-2">
            <Shield className="w-4 h-4" />
            APK Security Tester - For Educational Purposes Only
          </p>
          <p className="text-sm mt-2">Use only on your own APKs</p>
        </footer>
      </main>
    </div>
  );
}

export default App;

#!/usr/bin/env python3
"""
APK Login Security Tester
=========================
A tool to test if your APK's login page can be bypassed or removed.
Use this ONLY on APKs you own/have created for security testing purposes.

Author: Security Testing Tool
Purpose: Test your own APK's login security before release
"""

import os
import sys
import subprocess
import argparse
import json
import re
from pathlib import Path

class APKLoginTester:
    def __init__(self, apk_path):
        self.apk_path = apk_path
        self.apk_name = os.path.basename(apk_path)
        self.work_dir = os.path.join(os.getcwd(), "apk_test_workspace")
        self.decompiled_dir = os.path.join(self.work_dir, "decompiled")
        self.results = []
        
    def print_banner(self):
        print("""
╔══════════════════════════════════════════════════════════════╗
║           APK LOGIN SECURITY TESTER                          ║
║           Test Your APK's Login Security                     ║
╚══════════════════════════════════════════════════════════════╝
⚠️  WARNING: Use this tool ONLY on APKs you own/created!
""")
        
    def check_dependencies(self):
        """Check if required tools are installed"""
        print("[+] Checking dependencies...")
        tools = {
            'apktool': 'APKTool (https://ibotpeaches.github.io/Apktool/)',
            'jadx': 'JADX (https://github.com/skylot/jadx)',
            'java': 'Java JDK',
            'keytool': 'Keytool (comes with JDK)'
        }
        
        missing = []
        for tool, desc in tools.items():
            result = subprocess.run(['which', tool], capture_output=True)
            if result.returncode != 0:
                missing.append(f"  - {tool}: {desc}")
            else:
                print(f"  ✓ {tool} found")
                
        if missing:
            print("\n[!] Missing tools:")
            for m in missing:
                print(m)
            print("\n[+] Install APKTool:")
            print("    wget https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool")
            print("    wget https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar")
            print("    sudo mv apktool /usr/local/bin/ && sudo mv apktool_*.jar /usr/local/bin/apktool.jar")
            print("    sudo chmod +x /usr/local/bin/apktool")
            print("\n[+] Install JADX:")
            print("    wget https://github.com/skylot/jadx/releases/download/v1.4.7/jadx-1.4.7.zip")
            print("    unzip jadx-*.zip -d /opt/jadx && sudo ln -s /opt/jadx/bin/jadx /usr/local/bin/jadx")
            return False
        return True
        
    def decompile_apk(self):
        """Decompile APK using APKTool"""
        print(f"\n[+] Decompiling {self.apk_name}...")
        os.makedirs(self.work_dir, exist_ok=True)
        
        cmd = ['apktool', 'd', '-f', '-o', self.decompiled_dir, self.apk_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("  ✓ APK decompiled successfully")
            print(f"  📁 Location: {self.decompiled_dir}")
            return True
        else:
            print(f"  ✗ Decompilation failed: {result.stderr}")
            return False
            
    def analyze_login_implementation(self):
        """Analyze how login is implemented"""
        print("\n[+] Analyzing login implementation...")
        
        findings = []
        smali_dir = os.path.join(self.decompiled_dir, 'smali')
        
        if not os.path.exists(smali_dir):
            print("  ✗ Smali directory not found")
            return findings
            
        # Search for login-related patterns in smali
        login_patterns = [
            (r'login|signin|authenticate', 'Login-related method'),
            (r'password|passwd|pwd', 'Password handling'),
            (r'shared.*preferences|getSharedPreferences', 'SharedPreferences usage'),
            (r'Intent.*\.class', 'Activity navigation'),
            (r'setResult.*RESULT_OK', 'Result setting'),
            (r'finish\(\)', 'Activity finish'),
        ]
        
        for root, dirs, files in os.walk(smali_dir):
            for file in files:
                if file.endswith('.smali'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            for pattern, desc in login_patterns:
                                if re.search(pattern, content, re.IGNORECASE):
                                    findings.append({
                                        'file': filepath.replace(self.decompiled_dir + '/', ''),
                                        'pattern': desc,
                                        'snippet': content[:500]
                                    })
                    except Exception as e:
                        continue
                        
        print(f"  Found {len(findings)} login-related patterns")
        return findings
        
    def check_vulnerabilities(self):
        """Check for common login bypass vulnerabilities"""
        print("\n[+] Checking for login bypass vulnerabilities...")
        
        vulns = []
        smali_dir = os.path.join(self.decompiled_dir, 'smali')
        
        # Vulnerability patterns
        checks = [
            {
                'name': 'Hardcoded Credentials',
                'pattern': r'const-string.*"(admin|password|123456|test)"',
                'severity': 'CRITICAL',
                'description': 'Credentials hardcoded in the app'
            },
            {
                'name': 'Weak Validation',
                'pattern': r'if-eqz.*login|if-nez.*login',
                'severity': 'HIGH',
                'description': 'Login validation can be bypassed by flipping condition'
            },
            {
                'name': 'Local Authentication Only',
                'pattern': r'shared.*preferences.*edit.*putBoolean.*login.*true',
                'severity': 'HIGH',
                'description': 'Login state stored locally, can be modified'
            },
            {
                'name': 'No Server Verification',
                'pattern': r'(?!.*http).*login.*true',
                'severity': 'MEDIUM',
                'description': 'No server-side verification detected'
            },
            {
                'name': 'Debug Mode Enabled',
                'pattern': r'android:debuggable="true"',
                'severity': 'LOW',
                'description': 'App is debuggable'
            }
        ]
        
        for check in checks:
            found = False
            for root, dirs, files in os.walk(smali_dir):
                for file in files:
                    if file.endswith('.smali'):
                        filepath = os.path.join(root, file)
                        try:
                            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                                if re.search(check['pattern'], content, re.IGNORECASE):
                                    vulns.append({
                                        'name': check['name'],
                                        'severity': check['severity'],
                                        'description': check['description'],
                                        'file': filepath.replace(self.decompiled_dir + '/', '')
                                    })
                                    found = True
                                    break
                        except:
                            continue
                if found:
                    break
                    
        return vulns
        
    def generate_bypass_methods(self, vulns):
        """Generate potential bypass methods based on vulnerabilities"""
        print("\n[+] Generating bypass methods...")
        
        methods = []
        
        for vuln in vulns:
            if vuln['name'] == 'Weak Validation':
                methods.append({
                    'title': 'Method 1: Flip Login Condition',
                    'steps': [
                        'Open smali file: ' + vuln['file'],
                        'Find: if-eqz or if-nez condition related to login',
                        'Change if-eqz to if-nez (or vice versa)',
                        'Recompile: apktool b ' + self.decompiled_dir,
                        'Sign APK and install'
                    ],
                    'difficulty': 'Easy'
                })
                
            if vuln['name'] == 'Local Authentication Only':
                methods.append({
                    'title': 'Method 2: Modify SharedPreferences',
                    'steps': [
                        'Root the test device/emulator',
                        'Install and open app once',
                        'Run: adb shell',
                        'cd /data/data/[package]/shared_prefs',
                        'Edit XML to set logged_in=true',
                        'Restart app - login bypassed!'
                    ],
                    'difficulty': 'Medium'
                })
                
            if vuln['name'] == 'Hardcoded Credentials':
                methods.append({
                    'title': 'Method 3: Use Hardcoded Credentials',
                    'steps': [
                        'Search smali for const-string with credentials',
                        'Use those credentials to login',
                        'Or extract and use directly'
                    ],
                    'difficulty': 'Very Easy'
                })
                
        # Always add general methods
        methods.append({
            'title': 'Method 4: Remove Login Activity from Manifest',
            'steps': [
                'Open: ' + os.path.join(self.decompiled_dir, 'AndroidManifest.xml'),
                'Find LoginActivity entry',
                'Change android:enabled="false" OR remove intent-filter',
                'Set MainActivity as launcher',
                'Recompile and sign'
            ],
            'difficulty': 'Medium'
        })
        
        methods.append({
            'title': 'Method 5: Direct Activity Launch',
            'steps': [
                'Find target activity name from manifest',
                'Use adb: adb shell am start -n package/.MainActivity',
                'Skip login by launching main activity directly',
                'May crash if app expects logged-in state'
            ],
            'difficulty': 'Easy'
        })
        
        return methods
        
    def create_test_report(self, vulns, methods):
        """Create a security test report"""
        report_path = os.path.join(self.work_dir, 'security_report.txt')
        
        with open(report_path, 'w') as f:
            f.write("=" * 70 + "\n")
            f.write("APK LOGIN SECURITY TEST REPORT\n")
            f.write("=" * 70 + "\n\n")
            f.write(f"APK: {self.apk_name}\n")
            f.write(f"Test Date: {subprocess.check_output(['date']).decode().strip()}\n\n")
            
            f.write("VULNERABILITIES FOUND\n")
            f.write("-" * 40 + "\n")
            if vulns:
                for v in vulns:
                    f.write(f"\n[{v['severity']}] {v['name']}\n")
                    f.write(f"  File: {v['file']}\n")
                    f.write(f"  Description: {v['description']}\n")
            else:
                f.write("No obvious vulnerabilities detected.\n")
                
            f.write("\n\nPOTENTIAL BYPASS METHODS\n")
            f.write("-" * 40 + "\n")
            for i, m in enumerate(methods, 1):
                f.write(f"\n{m['title']} [Difficulty: {m['difficulty']}]\n")
                for step in m['steps']:
                    f.write(f"  → {step}\n")
                    
            f.write("\n\n" + "=" * 70 + "\n")
            f.write("RECOMMENDATIONS TO SECURE YOUR APP\n")
            f.write("=" * 70 + "\n")
            f.write("""
1. SERVER-SIDE VALIDATION
   - Never trust client-side validation alone
   - Verify all login credentials on server
   - Use secure API endpoints with HTTPS

2. OBFUSCATION
   - Use ProGuard/R8 to obfuscate code
   - Encrypt sensitive strings
   - Use native code (JNI) for critical logic

3. CERTIFICATE PINNING
   - Pin SSL certificates to prevent MITM
   - Use libraries like OkHttp CertificatePinner

4. ROOT DETECTION
   - Detect rooted devices
   - Exit app if root detected (or limit functionality)

5. ANTI-TAMPERING
   - Verify app signature at runtime
   - Check for modification of critical files
   - Use safetyNet/Play Integrity API

6. SECURE STORAGE
   - Use Android Keystore for sensitive data
   - Never store passwords in SharedPreferences
   - Encrypt all local data

7. DEBUGGING PROTECTION
   - Disable debug mode in release
   - Detect and prevent debugging
   - Use anti-hooking techniques

8. CODE OBFUSCATION
   - Split login logic across multiple classes
   - Use reflection sparingly and obfuscate
   - Implement code virtualization if possible
""")
            
        print(f"\n[+] Report saved: {report_path}")
        return report_path
        
    def run_full_test(self):
        """Run complete security test"""
        self.print_banner()
        
        if not os.path.exists(self.apk_path):
            print(f"✗ APK not found: {self.apk_path}")
            return
            
        if not self.check_dependencies():
            return
            
        if not self.decompile_apk():
            return
            
        findings = self.analyze_login_implementation()
        vulns = self.check_vulnerabilities()
        methods = self.generate_bypass_methods(vulns)
        report = self.create_test_report(vulns, methods)
        
        # Print summary
        print("\n" + "=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        print(f"Vulnerabilities Found: {len(vulns)}")
        for v in vulns:
            print(f"  [{v['severity']}] {v['name']}")
        print(f"\nBypass Methods Possible: {len(methods)}")
        print(f"Full Report: {report}")
        print("\n⚠️  If vulnerabilities were found, your login CAN be bypassed!")
        print("📖 Read the report for detailed fix instructions.")
        

def main():
    parser = argparse.ArgumentParser(
        description='APK Login Security Tester - Test your own APKs!',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 apk_login_tester.py /path/to/your/app.apk
  
⚠️  WARNING: Only use this on APKs you own or have permission to test!
        """
    )
    parser.add_argument('apk', help='Path to APK file to test')
    parser.add_argument('--decompile-only', action='store_true', 
                        help='Only decompile the APK')
    parser.add_argument('--analyze-only', action='store_true',
                        help='Only analyze already decompiled APK')
    
    args = parser.parse_args()
    
    tester = APKLoginTester(args.apk)
    
    if args.decompile_only:
        tester.print_banner()
        tester.check_dependencies()
        tester.decompile_apk()
    else:
        tester.run_full_test()

if __name__ == '__main__':
    main()

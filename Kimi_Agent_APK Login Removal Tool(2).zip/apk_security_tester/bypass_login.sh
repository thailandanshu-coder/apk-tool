#!/bin/bash
# APK Login Bypass Helper Script
# ===============================
# This script helps test login bypass techniques
# USE ONLY ON YOUR OWN APKS!

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_banner() {
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║           APK LOGIN BYPASS TESTER                            ║"
    echo "║           For Security Testing Only!                         ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_help() {
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  decompile <apk>           - Decompile APK for analysis"
    echo "  recompile <folder>        - Recompile modified APK"
    echo "  sign <apk>                - Sign APK with test key"
    echo "  launch-activity <pkg> <activity>  - Launch activity directly"
    echo "  extract-prefs <package>   - Extract SharedPreferences"
    echo "  patch-login <smali_file>  - Patch login check in smali"
    echo "  full-test <apk>           - Run complete test suite"
    echo ""
    echo "Examples:"
    echo "  $0 decompile myapp.apk"
    echo "  $0 launch-activity com.example.app .MainActivity"
    echo "  $0 full-test myapp.apk"
}

check_tools() {
    local missing=()
    
    for tool in apktool jadx java keytool adb; do
        if ! command -v $tool &> /dev/null; then
            missing+=($tool)
        fi
    done
    
    if [ ${#missing[@]} -ne 0 ]; then
        echo -e "${RED}[!] Missing tools: ${missing[*]}${NC}"
        echo "Install them first!"
        exit 1
    fi
}

decompile_apk() {
    local apk="$1"
    local outdir="decompiled_$(basename "$apk" .apk)"
    
    echo -e "${GREEN}[+] Decompiling $apk...${NC}"
    apktool d -f -o "$outdir" "$apk"
    echo -e "${GREEN}[+] Decompiled to: $outdir${NC}"
}

recompile_apk() {
    local folder="$1"
    local outapk="mod_$(basename "$folder").apk"
    
    echo -e "${GREEN}[+] Recompiling $folder...${NC}"
    apktool b -o "$outapk" "$folder"
    echo -e "${GREEN}[+] Built: $outapk${NC}"
    echo -e "${YELLOW}[!] Don't forget to sign the APK!${NC}"
}

sign_apk() {
    local apk="$1"
    local keystore="test.keystore"
    local signed="signed_$(basename "$apk")"
    
    # Create keystore if not exists
    if [ ! -f "$keystore" ]; then
        echo -e "${GREEN}[+] Creating test keystore...${NC}"
        keytool -genkey -v -keystore "$keystore" -alias test \
                -keyalg RSA -keysize 2048 -validity 10000 \
                -dname "CN=Test, OU=Test, O=Test, L=Test, ST=Test, C=US" \
                -storepass password -keypass password
    fi
    
    echo -e "${GREEN}[+] Signing $apk...${NC}"
    jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
              -keystore "$keystore" -storepass password \
              "$apk" test
    
    # Align with zipalign if available
    if command -v zipalign &> /dev/null; then
        zipalign -v 4 "$apk" "$signed"
        mv "$signed" "$apk"
    fi
    
    echo -e "${GREEN}[+] Signed: $apk${NC}"
}

launch_activity() {
    local pkg="$1"
    local activity="$2"
    
    echo -e "${GREEN}[+] Launching $pkg/$activity...${NC}"
    adb shell am start -n "$pkg/$activity"
    echo -e "${GREEN}[+] Launched! Check your device.${NC}"
}

extract_prefs() {
    local pkg="$1"
    local outdir="extracted_prefs_$(date +%s)"
    
    echo -e "${GREEN}[+] Extracting SharedPreferences from $pkg...${NC}"
    mkdir -p "$outdir"
    
    # Requires root
    adb shell "su -c 'cp -r /data/data/$pkg/shared_prefs/* /sdcard/prefs_tmp/'" 2>/dev/null || {
        echo -e "${RED}[!] Need root access!${NC}"
        exit 1
    }
    
    adb pull /sdcard/prefs_tmp "$outdir/"
    adb shell "rm -rf /sdcard/prefs_tmp"
    
    echo -e "${GREEN}[+] Preferences extracted to: $outdir${NC}"
    echo -e "${YELLOW}[!] You can modify these and push back!${NC}"
}

patch_login_smali() {
    local smali_file="$1"
    local backup="${smali_file}.backup"
    
    echo -e "${GREEN}[+] Patching $smali_file...${NC}"
    
    # Backup original
    cp "$smali_file" "$backup"
    
    # Common patterns to patch
    # Pattern 1: if-eqz → if-nez (flip condition)
    sed -i 's/if-eqz\(.*login\)/if-nez\1/gi' "$smali_file"
    sed -i 's/if-nez\(.*login\)/if-eqz\1/gi' "$smali_file"
    
    # Pattern 2: const/4 v0, 0x0 → const/4 v0, 0x1 (return true)
    # This is a simplified example - real patching needs analysis
    
    echo -e "${GREEN}[+] Patched! Original saved as $backup${NC}"
    echo -e "${YELLOW}[!] Review changes before recompiling!${NC}"
}

full_test() {
    local apk="$1"
    local pkgname
    
    print_banner
    check_tools
    
    echo -e "${GREEN}[+] Starting full security test on $apk${NC}"
    
    # Step 1: Decompile
    decompile_apk "$apk"
    local outdir="decompiled_$(basename "$apk" .apk)"
    
    # Step 2: Extract package name
    pkgname=$(grep -o 'package="[^"]*"' "$outdir/AndroidManifest.xml" | head -1 | cut -d'"' -f2)
    echo -e "${GREEN}[+] Package name: $pkgname${NC}"
    
    # Step 3: Find login activity
    echo -e "${GREEN}[+] Looking for login-related activities...${NC}"
    grep -i "login\|signin\|auth" "$outdir/AndroidManifest.xml" || echo "No obvious login activity found"
    
    # Step 4: Find main activity
    echo -e "${GREEN}[+] Main activity:${NC}"
    grep -A1 "MAIN" "$outdir/AndroidManifest.xml" | grep "activity" || true
    
    # Step 5: Search for hardcoded credentials
    echo -e "${GREEN}[+] Searching for hardcoded credentials...${NC}"
    grep -ri "password\|admin\|123456" "$outdir/smali/" --include="*.smali" | head -10 || echo "None found"
    
    # Step 6: Check for weak validation
    echo -e "${GREEN}[+] Checking for weak validation patterns...${NC}"
    grep -r "if-eqz\|if-nez" "$outdir/smali/" --include="*.smali" | grep -i "login\|auth\|valid" | head -5 || true
    
    # Step 7: Check manifest for security issues
    echo -e "${GREEN}[+] Checking AndroidManifest.xml...${NC}"
    grep -i "debuggable\|allowBackup" "$outdir/AndroidManifest.xml" || echo "No obvious issues"
    
    echo ""
    echo -e "${GREEN}=================================${NC}"
    echo -e "${GREEN}Test Complete!${NC}"
    echo -e "${GREEN}Decompiled folder: $outdir${NC}"
    echo ""
    echo -e "${YELLOW}Next steps to try bypass:${NC}"
    echo "1. Try direct activity launch:"
    echo "   adb shell am start -n $pkgname/.MainActivity"
    echo ""
    echo "2. Modify smali code to bypass login check"
    echo "3. Recompile and test"
    echo ""
    echo -e "${RED}Remember: Only test on your own apps!${NC}"
}

# Main
case "$1" in
    decompile)
        [ -z "$2" ] && { echo "Usage: $0 decompile <apk>"; exit 1; }
        check_tools
        decompile_apk "$2"
        ;;
    recompile)
        [ -z "$2" ] && { echo "Usage: $0 recompile <folder>"; exit 1; }
        check_tools
        recompile_apk "$2"
        ;;
    sign)
        [ -z "$2" ] && { echo "Usage: $0 sign <apk>"; exit 1; }
        check_tools
        sign_apk "$2"
        ;;
    launch-activity)
        [ -z "$3" ] && { echo "Usage: $0 launch-activity <package> <activity>"; exit 1; }
        launch_activity "$2" "$3"
        ;;
    extract-prefs)
        [ -z "$2" ] && { echo "Usage: $0 extract-prefs <package>"; exit 1; }
        extract_prefs "$2"
        ;;
    patch-login)
        [ -z "$2" ] && { echo "Usage: $0 patch-login <smali_file>"; exit 1; }
        patch_login_smali "$2"
        ;;
    full-test)
        [ -z "$2" ] && { echo "Usage: $0 full-test <apk>"; exit 1; }
        full_test "$2"
        ;;
    *)
        print_banner
        print_help
        ;;
esac

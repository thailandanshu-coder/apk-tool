#!/usr/bin/env python3
"""
APK Security Tester - Web Server for Android (Termux)
=====================================================
Run this on your Android phone using Termux for a web-based interface
"""

import os
import sys
import json
import subprocess
import re
import shutil
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import cgi
import urllib.parse

WORK_DIR = os.path.join(os.path.expanduser('~'), 'APK-Security-Tester')
UPLOADS_DIR = os.path.join(WORK_DIR, 'uploads')
OUTPUTS_DIR = os.path.join(WORK_DIR, 'outputs')

# Ensure directories exist
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

# Store analysis results
analyses = {}

HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APK Security Tester</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            color: #fff;
            padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; }
        header {
            text-align: center;
            padding: 30px 0;
            border-bottom: 2px solid #e94560;
            margin-bottom: 30px;
        }
        header h1 { font-size: 2em; color: #e94560; margin-bottom: 10px; }
        header p { color: #888; }
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .card h2 {
            color: #e94560;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        .upload-area {
            border: 2px dashed #e94560;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .upload-area:hover {
            background: rgba(233, 69, 96, 0.1);
        }
        .upload-area input[type="file"] { display: none; }
        .btn {
            background: #e94560;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s;
            margin: 5px;
        }
        .btn:hover { background: #ff6b6b; transform: translateY(-2px); }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .progress-bar {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-fill {
            background: linear-gradient(90deg, #e94560, #ff6b6b);
            height: 30px;
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .log-container {
            background: #0a0a0a;
            border-radius: 10px;
            padding: 15px;
            font-family: monospace;
            font-size: 0.85em;
            max-height: 300px;
            overflow-y: auto;
            color: #0f0;
        }
        .log-entry { margin: 3px 0; }
        .vulnerability {
            background: rgba(255,0,0,0.1);
            border-left: 4px solid #ff0000;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .vulnerability.critical { border-color: #ff0000; }
        .vulnerability.high { border-color: #ff8800; }
        .vulnerability.medium { border-color: #ffcc00; }
        .vulnerability.low { border-color: #00ff00; }
        .bypass-method {
            background: rgba(0,255,0,0.05);
            border: 1px solid #00ff00;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .severity-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 10px;
        }
        .severity-critical { background: #ff0000; }
        .severity-high { background: #ff8800; }
        .severity-medium { background: #ffcc00; color: #000; }
        .severity-low { background: #00ff00; color: #000; }
        .hidden { display: none; }
        .warning {
            background: rgba(255, 193, 7, 0.2);
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .success {
            background: rgba(0, 255, 0, 0.2);
            border: 1px solid #00ff00;
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        code {
            background: #1a1a1a;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: monospace;
        }
        .file-list {
            list-style: none;
        }
        .file-list li {
            padding: 10px;
            background: rgba(255,255,255,0.05);
            margin: 5px 0;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .tab {
            padding: 10px 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .tab.active {
            background: #e94560;
        }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🔒 APK Security Tester</h1>
            <p>Test your APK's login security on Android</p>
        </header>
        
        <div class="warning">
            ⚠️ <strong>Important:</strong> Use this tool ONLY on APKs you own/created!
        </div>
        
        <div class="card">
            <h2>📱 Upload APK</h2>
            <form id="uploadForm" action="/analyze" method="post" enctype="multipart/form-data">
                <label class="upload-area" onclick="document.getElementById('apkFile').click()">
                    <input type="file" id="apkFile" name="apk" accept=".apk" required>
                    <div style="font-size: 3em;">📦</div>
                    <p style="margin-top: 15px;">Tap to select APK file</p>
                    <p id="selectedFile" style="color: #e94560; margin-top: 10px;"></p>
                </label>
                <div style="text-align: center; margin-top: 20px;">
                    <button type="submit" class="btn">🔍 Analyze APK</button>
                    <button type="button" class="btn" onclick="removeLogin()" style="background: #00aa00;">🔓 Remove Login</button>
                </div>
            </form>
        </div>
        
        <div id="progressSection" class="card hidden">
            <h2>⏳ Analysis Progress</h2>
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar" style="width: 0%">0%</div>
            </div>
            <div class="log-container" id="logContainer"></div>
        </div>
        
        <div id="resultsSection" class="hidden">
            <div class="tabs">
                <div class="tab active" onclick="showTab('summary')">Summary</div>
                <div class="tab" onclick="showTab('vulnerabilities')">Vulnerabilities</div>
                <div class="tab" onclick="showTab('bypass')">Bypass Methods</div>
            </div>
            
            <div id="summary" class="tab-content active">
                <div class="card">
                    <h2>📊 Analysis Summary</h2>
                    <div id="summaryContent"></div>
                </div>
            </div>
            
            <div id="vulnerabilities" class="tab-content">
                <div class="card">
                    <h2>⚠️ Vulnerabilities Found</h2>
                    <div id="vulnerabilitiesContent"></div>
                </div>
            </div>
            
            <div id="bypass" class="tab-content">
                <div class="card">
                    <h2>🔓 Bypass Methods</h2>
                    <div id="bypassContent"></div>
                </div>
            </div>
        </div>
        
        <div id="outputSection" class="hidden">
            <div class="card">
                <h2>📥 Modified APK</h2>
                <div id="outputContent"></div>
            </div>
        </div>
    </div>
    
    <script>
        let currentAnalysisId = null;
        let pollInterval = null;
        
        // File selection
        document.getElementById('apkFile').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('selectedFile').textContent = file.name;
            }
        });
        
        // Form submission
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            document.getElementById('progressSection').classList.remove('hidden');
            document.getElementById('resultsSection').classList.add('hidden');
            
            fetch('/analyze', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                currentAnalysisId = data.analysisId;
                startPolling();
            })
            .catch(err => {
                alert('Error: ' + err.message);
            });
        });
        
        function removeLogin() {
            const fileInput = document.getElementById('apkFile');
            if (!fileInput.files[0]) {
                alert('Please select an APK file first');
                return;
            }
            
            const formData = new FormData();
            formData.append('apk', fileInput.files[0]);
            
            document.getElementById('progressSection').classList.remove('hidden');
            document.getElementById('logContainer').innerHTML = '<div class="log-entry">Starting login removal...</div>';
            
            fetch('/remove-login', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('outputSection').classList.remove('hidden');
                    document.getElementById('outputContent').innerHTML = `
                        <div class="success">
                            <h3>✅ Login Removed Successfully!</h3>
                            <p>Output: <code>${data.output}</code></p>
                            <p style="margin-top: 15px;">Install with: <code>pm install ${data.output}</code></p>
                        </div>
                    `;
                } else {
                    alert('Failed: ' + data.error);
                }
            })
            .catch(err => {
                alert('Error: ' + err.message);
            });
        }
        
        function startPolling() {
            if (pollInterval) clearInterval(pollInterval);
            
            pollInterval = setInterval(() => {
                fetch('/analysis/' + currentAnalysisId)
                .then(r => r.json())
                .then(data => {
                    updateProgress(data);
                    
                    if (data.status === 'completed' || data.status === 'error') {
                        clearInterval(pollInterval);
                        if (data.status === 'completed') {
                            showResults(data);
                        }
                    }
                });
            }, 1000);
        }
        
        function updateProgress(data) {
            document.getElementById('progressBar').style.width = data.progress + '%';
            document.getElementById('progressBar').textContent = data.progress + '%';
            
            const logContainer = document.getElementById('logContainer');
            logContainer.innerHTML = data.logs.map(l => 
                `<div class="log-entry">[${new Date(l.time).toLocaleTimeString()}] ${l.message}</div>`
            ).join('');
            logContainer.scrollTop = logContainer.scrollHeight;
        }
        
        function showResults(data) {
            document.getElementById('resultsSection').classList.remove('hidden');
            
            // Summary
            document.getElementById('summaryContent').innerHTML = `
                <p><strong>Package:</strong> ${data.packageName || 'N/A'}</p>
                <p><strong>Main Activity:</strong> ${data.mainActivity || 'N/A'}</p>
                <p><strong>Vulnerabilities:</strong> ${data.vulnerabilities.length}</p>
                <p><strong>Bypass Methods:</strong> ${data.bypassMethods.length}</p>
            `;
            
            // Vulnerabilities
            const vulnsHtml = data.vulnerabilities.length === 0 
                ? '<p style="color: #0f0;">✓ No vulnerabilities found!</p>'
                : data.vulnerabilities.map(v => `
                    <div class="vulnerability ${v.severity}">
                        <strong>${v.name}</strong>
                        <span class="severity-badge severity-${v.severity}">${v.severity}</span>
                        <p style="margin-top: 10px; color: #ccc;">${v.description}</p>
                        <p style="margin-top: 5px; color: #888;">Fix: ${v.fix || 'N/A'}</p>
                    </div>
                `).join('');
            document.getElementById('vulnerabilitiesContent').innerHTML = vulnsHtml;
            
            // Bypass methods
            const bypassHtml = data.bypassMethods.map(m => `
                <div class="bypass-method">
                    <h4>${m.title} <span style="color: #888;">(${m.difficulty})</span></h4>
                    <p style="margin: 10px 0; color: #ccc;">${m.description}</p>
                    ${m.command ? `<p>Command: <code>${m.command}</code></p>` : ''}
                    <ol style="margin-top: 10px; padding-left: 20px;">
                        ${m.steps.map(s => `<li style="margin: 5px 0;">${s}</li>`).join('')}
                    </ol>
                </div>
            `).join('');
            document.getElementById('bypassContent').innerHTML = bypassHtml;
        }
        
        function showTab(tabName) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        }
    </script>
</body>
</html>
'''

class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        
        if path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML_TEMPLATE.encode())
            
        elif path == '/analysis/' + path.split('/')[-1] and len(path.split('/')) == 3:
            analysis_id = path.split('/')[-1]
            if analysis_id in analyses:
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(analyses[analysis_id]).encode())
            else:
                self.send_response(404)
                self.end_headers()
                
        elif path == '/download':
            query = urllib.parse.parse_qs(parsed_path.query)
            if 'file' in query:
                file_path = query['file'][0]
                if os.path.exists(file_path) and file_path.startswith(OUTPUTS_DIR):
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.android.package-archive')
                    self.send_header('Content-Disposition', f'attachment; filename={os.path.basename(file_path)}')
                    self.end_headers()
                    with open(file_path, 'rb') as f:
                        self.wfile.write(f.read())
                else:
                    self.send_response(404)
                    self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_POST(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        
        if path == '/analyze':
            self.handle_analyze()
        elif path == '/remove-login':
            self.handle_remove_login()
        else:
            self.send_response(404)
            self.end_headers()
    
    def handle_analyze(self):
        content_type = self.headers.get('Content-Type', '')
        
        if 'multipart/form-data' in content_type:
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD': 'POST'}
            )
            
            if 'apk' in form:
                apk_item = form['apk']
                apk_name = apk_item.filename
                apk_data = apk_item.file.read()
                
                # Save APK
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                analysis_id = f"analysis_{timestamp}"
                apk_path = os.path.join(UPLOADS_DIR, f"{analysis_id}_{apk_name}")
                
                with open(apk_path, 'wb') as f:
                    f.write(apk_data)
                
                # Initialize analysis
                analyses[analysis_id] = {
                    'id': analysis_id,
                    'filename': apk_name,
                    'status': 'analyzing',
                    'progress': 0,
                    'logs': [{'time': datetime.now().isoformat(), 'message': 'Starting analysis...'}],
                    'vulnerabilities': [],
                    'bypassMethods': [],
                    'packageName': None,
                    'mainActivity': None
                }
                
                # Start analysis in background
                import threading
                thread = threading.Thread(target=self.run_analysis, args=(analysis_id, apk_path))
                thread.daemon = True
                thread.start()
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'analysisId': analysis_id, 'status': 'analyzing'}).encode())
            else:
                self.send_response(400)
                self.end_headers()
        else:
            self.send_response(400)
            self.end_headers()
    
    def handle_remove_login(self):
        content_type = self.headers.get('Content-Type', '')
        
        if 'multipart/form-data' in content_type:
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD': 'POST'}
            )
            
            if 'apk' in form:
                apk_item = form['apk']
                apk_name = apk_item.filename
                apk_data = apk_item.file.read()
                
                # Save APK
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                apk_path = os.path.join(UPLOADS_DIR, f"remove_{timestamp}_{apk_name}")
                output_dir = os.path.join(OUTPUTS_DIR, f"no_login_{timestamp}")
                
                with open(apk_path, 'wb') as f:
                    f.write(apk_data)
                
                # Run login removal
                try:
                    output_apk = self.remove_login(apk_path, output_dir)
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({
                        'success': True,
                        'output': output_apk
                    }).encode())
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'success': False, 'error': str(e)}).encode())
            else:
                self.send_response(400)
                self.end_headers()
        else:
            self.send_response(400)
            self.end_headers()
    
    def run_analysis(self, analysis_id, apk_path):
        analysis = analyses[analysis_id]
        work_dir = os.path.join(OUTPUTS_DIR, analysis_id)
        
        def log(msg):
            print(f"[{analysis_id}] {msg}")
            analysis['logs'].append({'time': datetime.now().isoformat(), 'message': msg})
        
        def update_progress(p):
            analysis['progress'] = p
        
        try:
            # Decompile
            update_progress(10)
            log('Decompiling APK...')
            
            decompiled_dir = os.path.join(work_dir, 'decompiled')
            result = subprocess.run(['apktool', 'd', '-f', '-o', decompiled_dir, apk_path],
                                  capture_output=True, text=True)
            
            if result.returncode != 0:
                log(f'Decompilation failed: {result.stderr}')
                analysis['status'] = 'error'
                return
            
            log('APK decompiled successfully')
            update_progress(30)
            
            # Analyze manifest
            log('Analyzing AndroidManifest.xml...')
            manifest_path = os.path.join(decompiled_dir, 'AndroidManifest.xml')
            
            if os.path.exists(manifest_path):
                with open(manifest_path, 'r') as f:
                    manifest = f.read()
                
                # Package name
                match = re.search(r'package="([^"]+)"', manifest)
                if match:
                    analysis['packageName'] = match.group(1)
                
                # Debug mode
                if 'android:debuggable="true"' in manifest:
                    analysis['vulnerabilities'].append({
                        'name': 'Debug Mode Enabled',
                        'severity': 'medium',
                        'description': 'App can be debugged',
                        'fix': 'Set android:debuggable="false"'
                    })
                
                # Allow backup
                if 'android:allowBackup="true"' in manifest:
                    analysis['vulnerabilities'].append({
                        'name': 'Allow Backup Enabled',
                        'severity': 'medium',
                        'description': 'App data can be backed up',
                        'fix': 'Set android:allowBackup="false"'
                    })
                
                # Main activity
                main_match = re.search(r'<activity[^>]*android:name="([^"]+)"[^>]*>[^<]*<intent-filter>[^<]*<action[^>]*android:name="android\.intent\.action\.MAIN"', manifest)
                if main_match:
                    analysis['mainActivity'] = main_match.group(1)
            
            update_progress(50)
            
            # Scan smali
            log('Scanning smali code...')
            smali_dir = os.path.join(decompiled_dir, 'smali')
            
            if os.path.exists(smali_dir):
                login_found = False
                prefs_found = False
                
                for root, dirs, files in os.walk(smali_dir):
                    for file in files:
                        if file.endswith('.smali'):
                            filepath = os.path.join(root, file)
                            try:
                                with open(filepath, 'r', errors='ignore') as f:
                                    content = f.read()
                                
                                if re.search(r'login|signin|authenticate', content, re.I):
                                    login_found = True
                                
                                if 'SharedPreferences' in content:
                                    prefs_found = True
                                
                                # Hardcoded creds
                                creds = re.findall(r'const-string[^,]+,\s*"(admin|password|123456)"', content, re.I)
                                if creds:
                                    analysis['vulnerabilities'].append({
                                        'name': 'Hardcoded Credentials',
                                        'severity': 'critical',
                                        'description': f'Found: {creds[0]}',
                                        'fix': 'Remove hardcoded credentials'
                                    })
                            except:
                                pass
                
                if login_found and prefs_found:
                    analysis['vulnerabilities'].append({
                        'name': 'Local Authentication',
                        'severity': 'high',
                        'description': 'Login state stored locally',
                        'fix': 'Use server-side authentication'
                    })
            
            update_progress(70)
            
            # Generate bypass methods
            log('Generating bypass methods...')
            package = analysis.get('packageName', 'com.example')
            main = analysis.get('mainActivity', '.MainActivity')
            
            analysis['bypassMethods'].append({
                'title': 'Direct Activity Launch',
                'difficulty': 'Very Easy',
                'description': 'Launch main activity directly',
                'command': f'am start -n {package}/{main}',
                'steps': ['Open Termux', f'Run: am start -n {package}/{main}', 'Check if app opens']
            })
            
            if any(v['name'] == 'Local Authentication' for v in analysis['vulnerabilities']):
                analysis['bypassMethods'].append({
                    'title': 'Modify SharedPreferences',
                    'difficulty': 'Medium',
                    'description': 'Fake logged-in state',
                    'steps': [
                        f'Navigate to /data/data/{package}/shared_prefs/',
                        'Find preferences file',
                        'Change is_logged_in to true',
                        'Restart app'
                    ]
                })
            
            analysis['bypassMethods'].append({
                'title': 'Smali Modification',
                'difficulty': 'Hard',
                'description': 'Modify decompiled code',
                'steps': [
                    f'Decompile: apktool d {analysis["filename"]} -o out',
                    'Find LoginActivity.smali',
                    'Change if-eqz to if-nez',
                    'Recompile and sign'
                ]
            })
            
            update_progress(100)
            log('Analysis complete!')
            analysis['status'] = 'completed'
            
        except Exception as e:
            log(f'Error: {str(e)}')
            analysis['status'] = 'error'
    
    def remove_login(self, apk_path, output_dir):
        os.makedirs(output_dir, exist_ok=True)
        decompiled_dir = os.path.join(output_dir, 'decompiled')
        
        # Decompile
        result = subprocess.run(['apktool', 'd', '-f', '-o', decompiled_dir, apk_path],
                              capture_output=True, text=True)
        if result.returncode != 0:
            raise Exception(f'Decompilation failed: {result.stderr}')
        
        # Modify manifest
        manifest_path = os.path.join(decompiled_dir, 'AndroidManifest.xml')
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                manifest = f.read()
            
            # Disable login activities
            for pattern in ['login', 'signin', 'auth']:
                manifest = re.sub(
                    rf'(<activity[^>]*android:name="[^"]*{pattern}[^"]*"[^>]*)>',
                    r'\1 android:enabled="false">',
                    manifest,
                    flags=re.I
                )
            
            with open(manifest_path, 'w') as f:
                f.write(manifest)
        
        # Modify smali
        smali_dir = os.path.join(decompiled_dir, 'smali')
        if os.path.exists(smali_dir):
            for root, dirs, files in os.walk(smali_dir):
                for file in files:
                    if 'login' in file.lower() or 'auth' in file.lower():
                        filepath = os.path.join(root, file)
                        with open(filepath, 'r', errors='ignore') as f:
                            content = f.read()
                        
                        original = content
                        content = re.sub(r'if-eqz\s+(v\d+),\s*(:cond_\w+)', r'if-nez \1, \2', content)
                        
                        if content != original:
                            with open(filepath, 'w') as f:
                                f.write(content)
        
        # Recompile
        unsigned_apk = os.path.join(output_dir, 'unsigned.apk')
        result = subprocess.run(['apktool', 'b', '-o', unsigned_apk, decompiled_dir],
                              capture_output=True, text=True)
        if result.returncode != 0:
            raise Exception(f'Recompilation failed: {result.stderr}')
        
        # Sign
        keystore = os.path.join(output_dir, 'test.keystore')
        if not os.path.exists(keystore):
            subprocess.run([
                'keytool', '-genkey', '-v',
                '-keystore', keystore,
                '-alias', 'test',
                '-keyalg', 'RSA',
                '-validity', '10000',
                '-dname', 'CN=Test',
                '-storepass', 'password',
                '-keypass', 'password'
            ], capture_output=True)
        
        output_apk = os.path.join(output_dir, os.path.basename(apk_path).replace('.apk', '_no_login.apk'))
        subprocess.run([
            'jarsigner', '-keystore', keystore,
            '-storepass', 'password',
            unsigned_apk, 'test'
        ], capture_output=True)
        
        shutil.move(unsigned_apk, output_apk)
        return output_apk
    
    def log_message(self, format, *args):
        pass  # Suppress default logging

def main():
    port = 8080
    server = HTTPServer(('0.0.0.0', port), RequestHandler)
    
    print(f'''
╔══════════════════════════════════════════════════════════════╗
║           APK Security Tester - Web Server                   ║
║           Running on http://localhost:{port}                    ║
╚══════════════════════════════════════════════════════════════╝

Open this URL in your phone's browser to use the tool.

⚠️  Use only on your own APKs!
''')
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")

if __name__ == '__main__':
    main()

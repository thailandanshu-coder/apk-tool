#!/bin/bash
# APK Security Tester - Termux Setup Script
# ==========================================
# Run this script in Termux to set up the tool on your Android phone

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_banner() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║     APK Security Tester - Android (Termux) Setup            ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Update packages
echo -e "${GREEN}[+] Updating packages...${NC}"
apt update && apt upgrade -y

# Install required packages
echo -e "${GREEN}[+] Installing required packages...${NC}"
apt install -y \
    python \
    python-pip \
    openjdk-17 \
    wget \
    curl \
    git \
    nano \
    termux-api \
    tsu

# Install APKTool
echo -e "${GREEN}[+] Installing APKTool...${NC}"
if [ ! -f $PREFIX/bin/apktool ]; then
    wget -q https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool -O $PREFIX/bin/apktool
    wget -q https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar -O $PREFIX/bin/apktool.jar
    chmod +x $PREFIX/bin/apktool
    echo -e "${GREEN}[+] APKTool installed!${NC}"
else
    echo -e "${GREEN}[+] APKTool already installed${NC}"
fi

# Create working directory
echo -e "${GREEN}[+] Creating working directory...${NC}"
WORK_DIR="$HOME/APK-Security-Tester"
mkdir -p $WORK_DIR
mkdir -p $WORK_DIR/uploads
mkdir -p $WORK_DIR/outputs

# Download the tools
echo -e "${GREEN}[+] Downloading tools...${NC}"
cd $WORK_DIR

# Create the main analysis tool
cat > apk_analyzer.py << 'PYTHON_EOF'
#!/usr/bin/env python3
"""
APK Security Analyzer for Android (Termux)
==========================================
Analyze APK files for login vulnerabilities
"""

import os
import sys
import subprocess
import re
import json
from datetime import datetime

class APKAnalyzer:
    def __init__(self, apk_path):
        self.apk_path = apk_path
        self.apk_name = os.path.basename(apk_path)
        self.work_dir = os.path.join(os.path.dirname(apk_path), "analysis_" + str(int(datetime.now().timestamp())))
        self.results = {
            "apk_name": self.apk_name,
            "analysis_time": datetime.now().isoformat(),
            "vulnerabilities": [],
            "bypass_methods": [],
            "logs": []
        }
        
    def log(self, message):
        print(f"[+] {message}")
        self.results["logs"].append(message)
        
    def analyze(self):
        """Run complete analysis"""
        self.log(f"Starting analysis of {self.apk_name}")
        
        # Decompile APK
        if not self.decompile():
            return None
            
        # Analyze manifest
        self.analyze_manifest()
        
        # Scan smali
        self.scan_smali()
        
        # Generate bypass methods
        self.generate_bypass_methods()
        
        # Save report
        return self.save_report()
        
    def decompile(self):
        """Decompile APK using apktool"""
        self.log("Decompiling APK...")
        
        os.makedirs(self.work_dir, exist_ok=True)
        
        cmd = ['apktool', 'd', '-f', '-o', os.path.join(self.work_dir, 'decompiled'), self.apk_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            self.log("APK decompiled successfully")
            return True
        else:
            self.log(f"Decompilation failed: {result.stderr}")
            return False
            
    def analyze_manifest(self):
        """Analyze AndroidManifest.xml"""
        manifest_path = os.path.join(self.work_dir, 'decompiled', 'AndroidManifest.xml')
        
        if not os.path.exists(manifest_path):
            self.log("AndroidManifest.xml not found")
            return
            
        with open(manifest_path, 'r') as f:
            content = f.read()
            
        # Extract package name
        package_match = re.search(r'package="([^"]+)"', content)
        if package_match:
            self.results["package_name"] = package_match.group(1)
            self.log(f"Package: {package_match.group(1)}")
            
        # Check debug mode
        if 'android:debuggable="true"' in content:
            self.results["vulnerabilities"].append({
                "name": "Debug Mode Enabled",
                "severity": "medium",
                "description": "App can be debugged",
                "fix": "Set android:debuggable='false' in AndroidManifest.xml"
            })
            self.log("Found: Debug mode enabled")
            
        # Check allowBackup
        if 'android:allowBackup="true"' in content:
            self.results["vulnerabilities"].append({
                "name": "Allow Backup Enabled",
                "severity": "medium",
                "description": "App data can be backed up and extracted",
                "fix": "Set android:allowBackup='false' in AndroidManifest.xml"
            })
            self.log("Found: Allow backup enabled")
            
        # Find main activity
        main_match = re.search(r'<activity[^>]*android:name="([^"]+)"[^>]*>[^<]*<intent-filter>[^<]*<action[^>]*android:name="android\.intent\.action\.MAIN"', content)
        if main_match:
            self.results["main_activity"] = main_match.group(1)
            self.log(f"Main activity: {main_match.group(1)}")
            
    def scan_smali(self):
        """Scan smali code for vulnerabilities"""
        smali_dir = os.path.join(self.work_dir, 'decompiled', 'smali')
        
        if not os.path.exists(smali_dir):
            self.log("Smali directory not found")
            return
            
        self.log("Scanning smali code...")
        
        login_found = False
        shared_prefs_found = False
        
        for root, dirs, files in os.walk(smali_dir):
            for file in files:
                if file.endswith('.smali'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', errors='ignore') as f:
                            content = f.read()
                            
                        if re.search(r'login|signin|authenticate', content, re.I):
                            login_found = True
                            
                        if 'SharedPreferences' in content or 'getSharedPreferences' in content:
                            shared_prefs_found = True
                            
                        # Check for hardcoded credentials
                        creds = re.findall(r'const-string[^,]+,\s*"(admin|password|123456|test)"', content, re.I)
                        if creds:
                            self.results["vulnerabilities"].append({
                                "name": "Potential Hardcoded Credentials",
                                "severity": "critical",
                                "description": f"Found hardcoded value: {creds[0]}",
                                "file": os.path.basename(filepath),
                                "fix": "Remove hardcoded credentials, use server-side authentication"
                            })
                            self.log(f"Found potential hardcoded credentials in {file}")
                            
                    except Exception as e:
                        pass
                        
        if login_found and shared_prefs_found:
            self.results["vulnerabilities"].append({
                "name": "Local Authentication",
                "severity": "high",
                "description": "Login state stored locally using SharedPreferences",
                "fix": "Use server-side session management with secure tokens"
            })
            self.log("Found: Local authentication (SharedPreferences)")
            
    def generate_bypass_methods(self):
        """Generate bypass methods based on findings"""
        package = self.results.get("package_name", "com.example")
        main_activity = self.results.get("main_activity", ".MainActivity")
        
        # Method 1: Direct launch
        self.results["bypass_methods"].append({
            "title": "Direct Activity Launch",
            "difficulty": "Very Easy",
            "description": "Launch main activity directly without login",
            "command": f"am start -n {package}/{main_activity}",
            "steps": [
                "Open Termux",
                f"Run: am start -n {package}/{main_activity}",
                "Check if app opens without login"
            ]
        })
        
        # Method 2: SharedPreferences (if applicable)
        if any(v["name"] == "Local Authentication" for v in self.results["vulnerabilities"]):
            self.results["bypass_methods"].append({
                "title": "Modify SharedPreferences",
                "difficulty": "Medium",
                "description": "Modify local storage to bypass login",
                "steps": [
                    f"Navigate to: /data/data/{package}/shared_prefs/",
                    "Find the preferences XML file",
                    "Change 'is_logged_in' or similar to 'true'",
                    "Restart the app"
                ]
            })
            
        # Method 3: Smali modification
        self.results["bypass_methods"].append({
            "title": "Smali Code Modification",
            "difficulty": "Hard",
            "description": "Modify the decompiled code to bypass login",
            "steps": [
                f"Decompile: apktool d {self.apk_name} -o output",
                "Find LoginActivity.smali in output/smali/",
                "Look for 'if-eqz' condition related to login",
                "Change to 'if-nez' or replace with 'nop'",
                "Recompile: apktool b output -o mod.apk",
                "Sign the APK"
            ]
        })
        
    def save_report(self):
        """Save analysis report"""
        report_path = os.path.join(self.work_dir, 'report.json')
        
        with open(report_path, 'w') as f:
            json.dump(self.results, f, indent=2)
            
        self.log(f"Report saved: {report_path}")
        return report_path

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='APK Security Analyzer')
    parser.add_argument('apk', help='Path to APK file')
    args = parser.parse_args()
    
    analyzer = APKAnalyzer(args.apk)
    report = analyzer.analyze()
    
    if report:
        print(f"\n{'='*60}")
        print("ANALYSIS COMPLETE!")
        print(f"{'='*60}")
        print(f"Report: {report}")
        
        # Print summary
        vuln_count = len(analyzer.results["vulnerabilities"])
        bypass_count = len(analyzer.results["bypass_methods"])
        
        print(f"\nVulnerabilities found: {vuln_count}")
        print(f"Bypass methods: {bypass_count}")
        
        if vuln_count > 0:
            print("\n⚠️  This APK can be bypassed!")
    else:
        print("\n❌ Analysis failed!")
        sys.exit(1)

if __name__ == '__main__':
    main()
PYTHON_EOF

chmod +x apk_analyzer.py

# Create login remover tool
cat > apk_login_remover.py << 'PYTHON_EOF'
#!/usr/bin/env python3
"""
APK Login Remover for Android (Termux)
======================================
Remove login from APK files on Android
"""

import os
import sys
import subprocess
import re
import shutil

class APKLoginRemover:
    def __init__(self, apk_path):
        self.apk_path = os.path.abspath(apk_path)
        self.apk_name = os.path.basename(apk_path)
        self.work_dir = os.path.join(os.path.dirname(apk_path), f"no_login_{os.path.splitext(self.apk_name)[0]}")
        
    def log(self, message):
        print(f"[+] {message}")
        
    def remove_login(self):
        """Remove login from APK"""
        self.log(f"Processing: {self.apk_name}")
        
        # Decompile
        if not self.decompile():
            return None
            
        # Modify manifest
        self.modify_manifest()
        
        # Try to modify smali
        self.modify_smali()
        
        # Recompile
        if not self.recompile():
            return None
            
        # Sign
        if not self.sign():
            return None
            
        return self.get_output_path()
        
    def decompile(self):
        """Decompile APK"""
        self.log("Decompiling APK...")
        os.makedirs(self.work_dir, exist_ok=True)
        
        decompiled_dir = os.path.join(self.work_dir, 'decompiled')
        cmd = ['apktool', 'd', '-f', '-o', decompiled_dir, self.apk_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            self.log("Decompiled successfully")
            return True
        else:
            self.log(f"Decompilation failed: {result.stderr}")
            return False
            
    def modify_manifest(self):
        """Modify AndroidManifest.xml to disable login"""
        manifest_path = os.path.join(self.work_dir, 'decompiled', 'AndroidManifest.xml')
        
        if not os.path.exists(manifest_path):
            return
            
        with open(manifest_path, 'r') as f:
            content = f.read()
            
        # Find login activity
        login_patterns = ['login', 'signin', 'auth', 'splash']
        
        for pattern in login_patterns:
            # Try to find and disable login activity
            if f'android:name=".{pattern.capitalize()}Activity"' in content.lower():
                self.log(f"Found login activity: {pattern}")
                # Add enabled="false" to disable it
                content = re.sub(
                    rf'(<activity[^>]*android:name="[^"]*{pattern}[^"]*"[^>]*)>',
                    r'\1 android:enabled="false">',
                    content,
                    flags=re.I
                )
                
        # Write back
        with open(manifest_path, 'w') as f:
            f.write(content)
            
        self.log("AndroidManifest.xml modified")
        
    def modify_smali(self):
        """Modify smali code to bypass login"""
        smali_dir = os.path.join(self.work_dir, 'decompiled', 'smali')
        
        if not os.path.exists(smali_dir):
            return
            
        self.log("Scanning smali files...")
        
        for root, dirs, files in os.walk(smali_dir):
            for file in files:
                if 'login' in file.lower() or 'auth' in file.lower():
                    filepath = os.path.join(root, file)
                    
                    with open(filepath, 'r', errors='ignore') as f:
                        content = f.read()
                        
                    original = content
                    
                    # Bypass login check
                    content = re.sub(
                        r'if-eqz\s+(v\d+),\s*(:cond_\w+)',
                        r'if-nez \1, \2  # Bypassed',
                        content
                    )
                    
                    if content != original:
                        with open(filepath, 'w') as f:
                            f.write(content)
                        self.log(f"Modified: {file}")
                        
    def recompile(self):
        """Recompile APK"""
        self.log("Recompiling APK...")
        
        output_apk = os.path.join(self.work_dir, 'unsigned.apk')
        decompiled_dir = os.path.join(self.work_dir, 'decompiled')
        
        cmd = ['apktool', 'b', '-o', output_apk, decompiled_dir]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            self.log("Recompiled successfully")
            return True
        else:
            self.log(f"Recompilation failed: {result.stderr}")
            return False
            
    def sign(self):
        """Sign the APK"""
        self.log("Signing APK...")
        
        unsigned_apk = os.path.join(self.work_dir, 'unsigned.apk')
        signed_apk = os.path.join(self.work_dir, f'{os.path.splitext(self.apk_name)[0]}_no_login.apk')
        keystore = os.path.join(self.work_dir, 'test.keystore')
        
        # Create keystore if not exists
        if not os.path.exists(keystore):
            cmd = [
                'keytool', '-genkey', '-v',
                '-keystore', keystore,
                '-alias', 'test',
                '-keyalg', 'RSA',
                '-validity', '10000',
                '-dname', 'CN=Test',
                '-storepass', 'password',
                '-keypass', 'password'
            ]
            subprocess.run(cmd, capture_output=True)
            
        # Sign
        cmd = [
            'jarsigner', '-verbose',
            '-keystore', keystore,
            '-storepass', 'password',
            unsigned_apk, 'test'
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0 or result.returncode == 1:  # 1 is warning
            shutil.move(unsigned_apk, signed_apk)
            self.log(f"Signed: {signed_apk}")
            return True
        else:
            self.log(f"Signing failed: {result.stderr}")
            return False
            
    def get_output_path(self):
        """Get output APK path"""
        return os.path.join(self.work_dir, f'{os.path.splitext(self.apk_name)[0]}_no_login.apk')

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='APK Login Remover')
    parser.add_argument('apk', help='Path to APK file')
    args = parser.parse_args()
    
    remover = APKLoginRemover(args.apk)
    output = remover.remove_login()
    
    if output:
        print(f"\n{'='*60}")
        print("✅ LOGIN REMOVED SUCCESSFULLY!")
        print(f"{'='*60}")
        print(f"Output: {output}")
        print(f"\nInstall with:")
        print(f"  pm install {output}")
    else:
        print("\n❌ Failed to remove login!")
        sys.exit(1)

if __name__ == '__main__':
    main()
PYTHON_EOF

chmod +x apk_login_remover.py

# Create launcher script
cat > start.sh << 'EOF'
#!/bin/bash
cd $HOME/APK-Security-Tester

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           APK Security Tester - Android                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "1. Analyze APK (find vulnerabilities)"
echo "2. Remove Login from APK"
echo "3. View previous reports"
echo "4. Exit"
echo ""
read -p "Select option: " choice

case $choice in
    1)
        read -p "Enter APK path: " apk
        python3 apk_analyzer.py "$apk"
        ;;
    2)
        read -p "Enter APK path: " apk
        python3 apk_login_remover.py "$apk"
        ;;
    3)
        ls -la $HOME/APK-Security-Tester/*/report.json 2>/dev/null || echo "No reports found"
        ;;
    4)
        exit 0
        ;;
    *)
        echo "Invalid option"
        ;;
esac
EOF

chmod +x start.sh

# Create shortcut
cat > $PREFIX/bin/apk-tester << EOF
#!/bin/bash
cd $HOME/APK-Security-Tester
bash start.sh
EOF
chmod +x $PREFIX/bin/apk-tester

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           Setup Complete!                                   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Usage:"
echo "  apk-tester              - Launch interactive menu"
echo "  python3 apk_analyzer.py <apk>    - Analyze APK"
echo "  python3 apk_login_remover.py <apk> - Remove login"
echo ""
echo "Working directory: $WORK_DIR"
echo ""
echo "⚠️  Use only on your own APKs!"

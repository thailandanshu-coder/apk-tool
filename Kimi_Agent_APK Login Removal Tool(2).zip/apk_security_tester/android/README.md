# APK Security Tester for Android

> **Run APK login security tests directly on your Android phone!**

## 📱 What You Get

A complete Android-based tool that lets you:
- ✅ Analyze APK files for login vulnerabilities
- ✅ Remove login from APKs automatically
- ✅ Get detailed security reports
- ✅ All from your phone - no computer needed!

---

## 🚀 Quick Setup (2 minutes)

### Step 1: Install Termux

Download from Play Store:
**[Termux - Google Play Store](https://play.google.com/store/apps/details?id=com.termux)**

Or F-Droid:
**[Termux - F-Droid](https://f-droid.org/packages/com.termux/)**

### Step 2: Run Setup Script

Open Termux and paste these commands:

```bash
# Update packages
pkg update -y && pkg upgrade -y

# Install required packages
pkg install -y python wget git

# Download and run setup
cd ~
wget https://raw.githubusercontent.com/yourusername/apk-tester/main/android/termux_setup.sh
bash termux_setup.sh
```

Or manually:

```bash
# Create directory
mkdir -p ~/APK-Security-Tester
cd ~/APK-Security-Tester

# Download the tools
# (Copy the files from this folder to your phone)
```

### Step 3: Start Using

```bash
# Start the web interface
python3 web_server.py
```

Then open your phone's browser and go to:
```
http://localhost:8080
```

---

## 📋 Usage Guide

### Method 1: Web Interface (Recommended)

1. Run `python3 web_server.py`
2. Open browser at `http://localhost:8080`
3. Tap "Select APK file"
4. Choose your APK
5. Tap "Analyze APK" or "Remove Login"
6. View results!

### Method 2: Command Line

```bash
# Analyze APK
python3 apk_analyzer.py /path/to/your.apk

# Remove login
python3 apk_login_remover.py /path/to/your.apk
```

---

## 📁 Files Included

| File | Purpose |
|------|---------|
| `web_server.py` | Web interface (recommended) |
| `apk_analyzer.py` | Command-line analyzer |
| `apk_login_remover.py` | Command-line login remover |
| `termux_setup.sh` | Automated setup script |

---

## 🎯 Features

### Analysis Features
- ✅ APK decompilation
- ✅ AndroidManifest.xml analysis
- ✅ Smali code scanning
- ✅ Hardcoded credential detection
- ✅ Local authentication detection
- ✅ Bypass method generation

### Login Removal Features
- ✅ Automatic login activity detection
- ✅ Manifest modification
- ✅ Smali code patching
- ✅ APK recompilation
- ✅ Automatic signing

---

## 📊 Sample Output

### Analysis Report
```
══════════════════════════════════════════
APK: MyApp.apk
Package: com.example.myapp
══════════════════════════════════════════

Vulnerabilities Found: 3
  [CRITICAL] Hardcoded Credentials
  [HIGH] Local Authentication
  [MEDIUM] Debug Mode Enabled

Bypass Methods: 3
  1. Direct Activity Launch (Very Easy)
     Command: am start -n com.example.myapp/.MainActivity
     
  2. SharedPreferences Modification (Medium)
     Steps: [...]
     
  3. Smali Modification (Hard)
     Steps: [...]
```

### Login Removal Output
```
══════════════════════════════════════════
✅ LOGIN REMOVED SUCCESSFULLY!
══════════════════════════════════════════

Output: MyApp_no_login.apk
Location: ~/APK-Security-Tester/outputs/

Install with:
  pm install MyApp_no_login.apk
```

---

## 🔧 Manual Installation

If automatic setup doesn't work:

```bash
# 1. Install dependencies
pkg install python openjdk-17 apktool

# 2. Create directories
mkdir -p ~/APK-Security-Tester/{uploads,outputs}

# 3. Copy Python files
# Copy apk_analyzer.py, apk_login_remover.py, web_server.py

# 4. Run
python3 web_server.py
```

---

## ⚠️ Important Notes

1. **Use only on your own APKs!**
2. **Root access not required** for analysis
3. **Root access required** for installing modified APKs (usually)
4. Some apps may detect modification and crash

---

## 🆘 Troubleshooting

### "apktool: command not found"
```bash
pkg install apktool
```

### "java: command not found"
```bash
pkg install openjdk-17
```

### "Permission denied"
```bash
chmod +x *.py
chmod +x *.sh
```

### Web server not accessible
Make sure you're using `http://localhost:8080` in your phone's browser, not from another device.

---

## 📱 Screenshots

The web interface includes:
- Modern dark theme
- Drag & drop APK upload
- Real-time progress bar
- Tabbed results view
- Copy-paste commands

---

## 🎓 How It Works

1. **Upload APK** → File saved to uploads folder
2. **Decompile** → APKTool extracts the code
3. **Analyze** → Scans for vulnerabilities
4. **Report** → Generates findings and bypass methods
5. **Modify** → Patches login checks (if removing)
6. **Rebuild** → Creates modified APK
7. **Sign** → Makes APK installable

---

## 🔒 Security

- All processing happens **locally on your phone**
- No data sent to any server
- APKs stay on your device
- Source code is open and transparent

---

## 📞 Support

If you face issues:
1. Check Termux is updated
2. Re-run setup script
3. Check error messages in terminal

---

**Ready to test your APKs? Let's go! 🚀**

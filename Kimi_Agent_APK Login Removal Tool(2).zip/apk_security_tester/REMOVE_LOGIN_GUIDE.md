# APK Login Remover - Quick Guide

## 🚀 Login Remove Karne Ka Sabse Easy Tarika

### Step 1: Dependencies Install Karo (Ek Baar)

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y openjdk-11-jdk

# APKTool install
wget https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool
wget https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar
sudo mv apktool /usr/local/bin/
sudo mv apktool_*.jar /usr/local/bin/apktool.jar
sudo chmod +x /usr/local/bin/apktool

# Verify
apktool --version
```

### Step 2: APK Upload Karo

Aapki APK file ko is folder mein copy karo:
```bash
cp /path/to/your/app.apk /mnt/okcomputer/output/apk_security_tester/
```

### Step 3: Login Remove Karo

```bash
cd /mnt/okcomputer/output/apk_security_tester
python3 remove_login.py app.apk
```

### Step 4: Modified APK Lo

Output yahan milega:
```
login_removed_app/
├── app_no_login.apk          ← Ye modified APK hai!
├── INSTALL_INSTRUCTIONS.txt  ← Install karne ka tarika
└── decompiled/               ← Source code (agar dekhna ho)
```

---

## 📋 Kya Kya Hota Hai (Automatic)

1. **APK Decompile** → Code nikalo
2. **Login Dhoondo** → Manifest aur smali mein
3. **Login Hatao** → 2 methods se try karta hai
4. **APK Banao** → Nayi APK compile karo
5. **Sign Karo** → Install karne layak banao

---

## 🎯 Methods

### Method 1: AndroidManifest.xml Edit
- Login activity ko `enabled="false"` karta hai
- Main activity ko launcher banata hai

### Method 2: Smali Code Modify  
- Login check ko bypass karta hai
- `if-eqz` ko `if-nez` mein badalta hai

---

## ⚠️ Important

**Ye tool SIRF aapki khud ki APKs ke liye hai!**

- ✅ Apni app modify karna → ALLOWED
- ❌ Kisi aur ki app modify karna → ILLEGAL

---

## 🔧 Manual Method (Agar Automatic Fail Ho)

### Option 1: Direct Activity Launch
```bash
# Package name find karo
aapt dump badging app.apk | grep package

# Main activity launch karo (login skip)
adb shell am start -n com.yourpackage/.MainActivity
```

### Option 2: Smali Edit
```bash
# Decompile
apktool d app.apk -o output

# Login smali find karo
find output/smali -name "*Login*.smali"

# Edit karo (if-eqz ko if-nez karo)
nano output/smali/com/yourapp/LoginActivity.smali

# Recompile
apktool b output -o mod.apk

# Sign
jarsigner -keystore test.keystore mod.apk test
```

---

## 🆘 Help

Agar kuch problem aaye to:
1. Error message padho
2. Dependencies check karo
3. APK valid hai ki nahi check karo

---

**Ready? Chaliye shuru karte hain! 🚀**

```bash
cd /mnt/okcomputer/output/apk_security_tester
python3 remove_login.py your_app.apk
```

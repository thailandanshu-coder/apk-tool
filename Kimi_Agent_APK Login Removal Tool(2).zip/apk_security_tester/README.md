# APK Login Security Tester

> **⚠️ DISCLAIMER: This tool is for testing YOUR OWN APKs only!**
> 
> Using this on apps you don't own is illegal and unethical.

## Kya Hai Ye? (What is this?)

Agar aapne khud ka APK banaya hai aur check karna chahte hain ki koi hacker uska login page remove kar sakta hai ya nahi, to ye tool aapke kaam aayega!

## Features

✅ **APK Decompilation** - APK ko reverse engineer karna  
✅ **Vulnerability Scanning** - Common security issues dhoondna  
✅ **Bypass Method Generation** - Hacker kaise bypass karega  
✅ **Security Report** - Detailed analysis report  
✅ **Fix Recommendations** - App ko secure kaise banaye  

## Installation

### Step 1: Dependencies Install Karein

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y openjdk-11-jdk python3 python3-pip adb

# APKTool Install
wget https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool
wget https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar
sudo mv apktool /usr/local/bin/
sudo mv apktool_*.jar /usr/local/bin/apktool.jar
sudo chmod +x /usr/local/bin/apktool

# JADX Install
wget https://github.com/skylot/jadx/releases/download/v1.4.7/jadx-1.4.7.zip
sudo unzip jadx-*.zip -d /opt/jadx
sudo ln -s /opt/jadx/bin/jadx /usr/local/bin/jadx

# Verify installation
apktool --version
jadx --version
java -version
```

## Usage

### Method 1: Python Tool (Recommended)

```bash
# Full security test
python3 apk_login_tester.py /path/to/your/app.apk

# Output mein milega:
# - Vulnerabilities list
# - Bypass methods
# - Security report file
```

### Method 2: Bash Script

```bash
chmod +x bypass_login.sh

# Full test
./bypass_login.sh full-test your_app.apk

# Individual commands
./bypass_login.sh decompile your_app.apk
./bypass_login.sh recompile decompiled_folder
./bypass_login.sh sign modified.apk
```

## Common Login Bypass Techniques

### Technique 1: Direct Activity Launch
```bash
# Main activity ko directly launch karna
adb shell am start -n com.yourpackage/.MainActivity
```

### Technique 2: Modify Smali Code
```bash
# 1. APK decompile karo
apktool d app.apk -o decompiled

# 2. Login check wali smali file dhoondo
grep -r "if-eqz.*login" decompiled/smali/

# 3. Condition flip karo (if-eqz → if-nez)
# File: decompiled/smali/com/yourapp/LoginActivity.smali

# 4. Recompile karo
apktool b decompiled -o mod_app.apk

# 5. Sign karo
jarsigner -keystore test.keystore mod_app.apk test
```

### Technique 3: SharedPreferences Hack
```bash
# Agar app local storage mein "isLoggedIn" save karti hai:

# 1. Rooted device pe preferences extract karo
adb shell
su
cd /data/data/com.yourpackage/shared_prefs

# 2. XML edit karo
# Change: <boolean name="isLoggedIn" value="false" />
# To:     <boolean name="isLoggedIn" value="true" />

# 3. App restart karo - login bypassed!
```

### Technique 4: AndroidManifest.xml Edit
```xml
<!-- Original -->
<activity android:name=".LoginActivity">
    <intent-filter>
        <action android:name="android.intent.action.MAIN"/>
        <category android:name="android.intent.category.LAUNCHER"/>
    </intent-filter>
</activity>

<!-- Modified - Login hata diya -->
<activity android:name=".LoginActivity" android:enabled="false"/>
<activity android:name=".MainActivity">
    <intent-filter>
        <action android:name="android.intent.action.MAIN"/>
        <category android:name="android.intent.category.LAUNCHER"/>
    </intent-filter>
</activity>
```

## Security Checklist - Apni App Ko Secure Kaise Banaye

### ✅ 1. Server-Side Validation
```java
// ❌ GALAT - Client side only
if (username.equals("admin") && password.equals("123")) {
    loginSuccess();
}

// ✅ SAHI - Server verification
api.verifyLogin(username, password).enqueue(new Callback<AuthResponse>() {
    @Override
    public void onResponse(Response<AuthResponse> response) {
        if (response.body().isValid()) {
            loginSuccess();
        }
    }
});
```

### ✅ 2. Code Obfuscation (ProGuard/R8)
```proguard
# proguard-rules.pro
-obfuscationdictionary dict.txt
-classobfuscationdictionary dict.txt
-packageobfuscationdictionary dict.txt

# Login classes ko obfuscate karo
-repackageclasses 'a'
```

### ✅ 3. Root Detection
```java
public boolean isDeviceRooted() {
    return android.os.Build.TAGS.contains("test-keys") ||
           new File("/system/app/Superuser.apk").exists() ||
           new File("/system/xbin/su").exists();
}

// Agar rooted, app band karo
if (isDeviceRooted()) {
    finish();
    System.exit(0);
}
```

### ✅ 4. Certificate Pinning
```java
// OkHttp with Certificate Pinning
CertificatePinner certificatePinner = new CertificatePinner.Builder()
    .add("yourdomain.com", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
    .build();

OkHttpClient client = new OkHttpClient.Builder()
    .certificatePinner(certificatePinner)
    .build();
```

### ✅ 5. Anti-Tampering
```java
// Verify app signature at runtime
public boolean verifySignature(Context context) {
    try {
        PackageManager pm = context.getPackageManager();
        PackageInfo packageInfo = pm.getPackageInfo(
            context.getPackageName(), 
            PackageManager.GET_SIGNATURES
        );
        
        // Compare with your original signature hash
        byte[] signature = packageInfo.signatures[0].toByteArray();
        String currentHash = getSHA256(signature);
        return ORIGINAL_HASH.equals(currentHash);
    } catch (Exception e) {
        return false;
    }
}
```

### ✅ 6. Secure Storage
```java
// ❌ GALAT
SharedPreferences prefs = getSharedPreferences("login", MODE_PRIVATE);
prefs.edit().putBoolean("isLoggedIn", true).apply();

// ✅ SAHI - Android Keystore use karo
KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
keyStore.load(null);

// Encrypt sensitive data
Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
cipher.init(Cipher.ENCRYPT_MODE, getSecretKey());
```

### ✅ 7. Native Code (JNI) for Critical Logic
```c
// native-lib.c
#include <jni.h>

JNIEXPORT jboolean JNICALL
Java_com_yourapp_SecurityUtils_verifyLogin(
    JNIEnv *env, 
    jobject thiz, 
    jstring username, 
    jstring password
) {
    // Critical logic in native code (harder to reverse)
    const char *user = (*env)->GetStringUTFChars(env, username, 0);
    const char *pass = (*env)->GetStringUTFChars(env, password, 0);
    
    // Server verification logic
    return verify_with_server(user, pass);
}
```

### ✅ 8. Play Integrity API
```java
// Use Google's Play Integrity API
IntegrityManager integrityManager = IntegrityManagerFactory.create(context);

Task<IntegrityTokenResponse> integrityTokenResponse = integrityManager.requestIntegrityToken(
    IntegrityTokenRequest.builder()
        .setNonce(nonce)
        .setCloudProjectNumber(projectNumber)
        .build()
);
```

## Test Results Interpretation

### 🔴 CRITICAL Vulnerabilities
- Hardcoded credentials
- No server verification
- Weak encryption

### 🟡 HIGH Vulnerabilities
- Local authentication only
- Debug mode enabled
- AllowBackup=true

### 🟢 LOW Vulnerabilities
- Obfuscation missing
- Root detection missing

## Example Test Output

```
╔══════════════════════════════════════════════════════════════╗
║           APK LOGIN SECURITY TESTER                          ║
╚══════════════════════════════════════════════════════════════╝

[+] Checking dependencies...
  ✓ apktool found
  ✓ jadx found
  ✓ java found

[+] Decompiling myapp.apk...
  ✓ APK decompiled successfully
  📁 Location: apk_test_workspace/decompiled

[+] Analyzing login implementation...
  Found 15 login-related patterns

[+] Checking for login bypass vulnerabilities...

[+] Vulnerabilities Found:
  [CRITICAL] Hardcoded Credentials
    File: smali/com/myapp/LoginActivity.smali
    Description: Credentials hardcoded in the app

  [HIGH] Local Authentication Only
    File: smali/com/myapp/Utils.smali
    Description: Login state stored locally, can be modified

[+] Report saved: apk_test_workspace/security_report.txt

⚠️  If vulnerabilities were found, your login CAN be bypassed!
📖 Read the report for detailed fix instructions.
```

## Troubleshooting

### Issue: "apktool: command not found"
**Solution:** APKTool install nahi hua. Uppar diye gaye installation steps follow karo.

### Issue: "Cannot decompile protected APK"
**Solution:** APK already protected hai (DexGuard, etc.) - ye achhi baat hai!

### Issue: "App crashes after modification"
**Solution:** Smali code mein syntax error hai. Backup se restore karo aur carefully modify karo.

## Legal Notice

**Ye tool SIRF educational aur security testing purposes ke liye hai.**

- ✅ Apni khud ki apps test karna - ALLOWED
- ✅ Client ki apps (permission se) test karna - ALLOWED
- ❌ Kisi aur ki apps hack karna - ILLEGAL

## Next Steps

1. Apni APK ko test karo
2. Vulnerabilities note karo
3. Upar diye gaye solutions implement karo
4. Dobara test karo
5. Launch karo with confidence!

## Support

Agar koi problem aaye to:
1. README dhyan se padho
2. Dependencies check karo
3. Error message Google karo

---

**Happy Secure Coding! 🔒**

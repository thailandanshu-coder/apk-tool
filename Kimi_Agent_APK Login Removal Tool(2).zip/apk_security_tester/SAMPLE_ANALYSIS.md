# Sample APK Security Analysis

> Ye document ek sample vulnerable APK ki analysis dikhata hai taaki aap samajh saken ki kaise vulnerabilities dhoondi jaati hain aur kaise fix ki jaati hain.

## Sample Vulnerable APK Analysis

### APK Details
- **Name:** TestApp.apk
- **Package:** com.example.testapp
- **Version:** 1.0
- **Analysis Date:** 2024

### Step 1: Decompilation

```bash
$ apktool d TestApp.apk -o TestApp_decompiled
I: Using Apktool 2.9.1 on TestApp.apk
I: Loading resource table...
I: Decoding AndroidManifest.xml with resources...
I: Loading resource table from file: 1.apk
I: Regular manifest package...
I: Decoding file-resources...
I: Decoding values */* XMLs...
I: Baksmaling classes.dex...
I: Copying assets and libs...
I: Copying unknown files...
I: Built apk...
```

**Result:** ✅ Decompilation successful

---

### Step 2: AndroidManifest.xml Analysis

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.testapp">

    <!-- 🔴 ISSUE: Debug mode enabled -->
    <application
        android:allowBackup="true"        <!-- 🔴 ISSUE: Backup allowed -->
        android:debuggable="true"         <!-- 🔴 ISSUE: Debug enabled -->
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name">

        <!-- Login Activity -->
        <activity android:name=".LoginActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Main Activity - Protected Content -->
        <activity android:name=".MainActivity" />
        
    </application>
</manifest>
```

**Issues Found:**
| Issue | Severity | Description |
|-------|----------|-------------|
| `android:debuggable="true"` | 🔴 HIGH | App can be debugged |
| `android:allowBackup="true"` | 🟡 MEDIUM | Data can be backed up/extracted |

---

### Step 3: LoginActivity.smali Analysis

**File Location:** `smali/com/example/testapp/LoginActivity.smali`

```smali
.class public Lcom/example/testapp/LoginActivity;
.super Landroid/app/Activity;

# ...

.method private checkLogin(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2
    .param p1, "username"    # Ljava/lang/String;
    .param p2, "password"    # Ljava/lang/String;

    .prologue
    const/4 v0, 0x0

    # 🔴 ISSUE: Hardcoded credentials!
    const-string v1, "admin"
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v1
    if-eqz v1, :cond_0

    const-string v1, "password123"
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v1
    if-eqz v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0
.end method

.method private onLoginSuccess()V
    .locals 3

    .prologue
    # 🔴 ISSUE: Local authentication only
    const-string v0, "app_prefs"
    const/4 v1, 0x0
    invoke-virtual {p0, v0, v1}, Lcom/example/testapp/LoginActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v1, "is_logged_in"
    const/4 v2, 0x1
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    # Navigate to MainActivity
    new-instance v0, Landroid/content/Intent;
    const-class v1, Lcom/example/testapp/MainActivity;
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    invoke-virtual {p0, v0}, Lcom/example/testapp/LoginActivity;->startActivity(Landroid/content/Intent;)V
    invoke-virtual {p0}, Lcom/example/testapp/LoginActivity;->finish()V
    return-void
.end method
```

**Critical Issues Found:**

1. **Hardcoded Credentials** 🔴 CRITICAL
   - Username: `admin`
   - Password: `password123`

2. **Local Authentication** 🔴 HIGH
   - Login state stored in SharedPreferences
   - Can be easily modified

3. **No Server Verification** 🔴 HIGH
   - All authentication is local
   - No API calls for verification

---

### Step 4: Bypass Testing

#### Test 1: Direct Activity Launch
```bash
$ adb shell am start -n com.example.testapp/.MainActivity
Starting: Intent { cmp=com.example.testapp/.MainActivity }
```

**Result:** ✅ BYPASSED! App opened without login

#### Test 2: Hardcoded Credentials
```
Username: admin
Password: password123
```

**Result:** ✅ Login successful with hardcoded credentials

#### Test 3: SharedPreferences Modification
```bash
# 1. Access device shell
$ adb shell

# 2. Get root access
$ su

# 3. Navigate to app data
$ cd /data/data/com.example.testapp/shared_prefs

# 4. View preferences
$ cat app_prefs.xml
```

**Output:**
```xml
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="is_logged_in" value="false" />
</map>
```

**Modification:**
```bash
# Edit the file
$ echo '<?xml version="1.0" encoding="utf-8"?>
<map>
    <boolean name="is_logged_in" value="true" />
</map>' > app_prefs.xml
```

**Result:** ✅ BYPASSED! App shows logged-in state

#### Test 4: Smali Modification

**Original Code:**
```smali
invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
move-result v1
if-eqz v1, :cond_0    # Jump if not equal (login fails)
```

**Modified Code:**
```smali
invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
move-result v1
# if-eqz v1, :cond_0    # Commented out - always continue
nop                    # No operation
```

**Result:** ✅ BYPASSED! Any credentials work

---

## Vulnerability Summary

| # | Vulnerability | Severity | Exploit Difficulty |
|---|---------------|----------|-------------------|
| 1 | Hardcoded Credentials | 🔴 CRITICAL | Very Easy |
| 2 | Local Authentication Only | 🔴 HIGH | Easy |
| 3 | Direct Activity Launch | 🔴 HIGH | Very Easy |
| 4 | Debug Mode Enabled | 🟡 MEDIUM | Easy |
| 5 | Allow Backup | 🟡 MEDIUM | Easy |
| 6 | No Code Obfuscation | 🟢 LOW | Medium |

**Overall Security Rating: F (Critically Vulnerable)**

---

## Fix Recommendations

### Fix 1: Remove Hardcoded Credentials

**❌ Before:**
```java
private boolean checkLogin(String username, String password) {
    return username.equals("admin") && password.equals("password123");
}
```

**✅ After:**
```java
private void checkLogin(String username, String password) {
    // Server se verify karo
    apiService.login(username, password)
        .enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body().isValid()) {
                    onLoginSuccess(response.body().getToken());
                } else {
                    showError("Invalid credentials");
                }
            }
            
            @Override
            public void onFailure(Throwable t) {
                showError("Network error");
            }
        });
}
```

### Fix 2: Server-Side Session Management

**❌ Before:**
```java
// Local storage
SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
prefs.edit().putBoolean("is_logged_in", true).apply();
```

**✅ After:**
```java
// Server-side session with secure token storage
private void saveAuthToken(String token) {
    try {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        
        // Store encrypted token
        // ... encryption logic ...
        
    } catch (Exception e) {
        e.printStackTrace();
    }
}

// Verify session with server on each app start
private void verifySession() {
    String token = getSecureToken();
    apiService.verifyToken(token)
        .enqueue(new Callback<VerifyResponse>() {
            @Override
            public void onResponse(Response<VerifyResponse> response) {
                if (!response.isSuccessful()) {
                    logout();
                }
            }
        });
}
```

### Fix 3: Prevent Direct Activity Launch

**In MainActivity.java:**
```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    
    // Check if user is logged in
    if (!isUserLoggedIn()) {
        // Redirect to login
        startActivity(new Intent(this, LoginActivity.class));
        finish();
        return;
    }
    
    setContentView(R.layout.activity_main);
}

private boolean isUserLoggedIn() {
    // Verify with server, not local storage
    String token = getSecureToken();
    return token != null && isTokenValid(token);
}
```

### Fix 4: Disable Debug Mode

**In AndroidManifest.xml:**
```xml
<application
    android:debuggable="false"        <!-- ✅ Fixed -->
    android:allowBackup="false"       <!-- ✅ Fixed -->
    ... >
```

### Fix 5: Enable Code Obfuscation

**In build.gradle:**
```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile(
                'proguard-android-optimize.txt'
            ), 'proguard-rules.pro'
        }
    }
}
```

**In proguard-rules.pro:**
```proguard
# Obfuscate all classes
-repackageclasses 'a'
-obfuscationdictionary dict.txt
-classobfuscationdictionary dict.txt

# Keep only entry points
-keep public class com.example.testapp.MainActivity {
    public <methods>;
}
```

### Fix 6: Add Root Detection

```java
public class SecurityUtils {
    
    public static boolean isDeviceRooted() {
        return checkTestKeys() || 
               checkSuperUserApk() || 
               checkSuBinary() ||
               checkMagisk();
    }
    
    private static boolean checkTestKeys() {
        String buildTags = android.os.Build.TAGS;
        return buildTags != null && buildTags.contains("test-keys");
    }
    
    private static boolean checkSuperUserApk() {
        return new File("/system/app/Superuser.apk").exists();
    }
    
    private static boolean checkSuBinary() {
        String[] paths = {
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/su/bin/su"
        };
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        return false;
    }
    
    private static boolean checkMagisk() {
        return new File("/sbin/.magisk").exists();
    }
}

// Usage in LoginActivity
if (SecurityUtils.isDeviceRooted()) {
    Toast.makeText(this, "Rooted device detected!", Toast.LENGTH_LONG).show();
    finish();
    return;
}
```

### Fix 7: Add Anti-Tampering

```java
public class AntiTamper {
    
    private static final String EXPECTED_SIGNATURE = "YOUR_SIGNATURE_HASH";
    
    public static boolean verifyAppIntegrity(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageInfo(
                context.getPackageName(),
                PackageManager.GET_SIGNATURES
            );
            
            Signature[] signatures = packageInfo.signatures;
            byte[] signatureBytes = signatures[0].toByteArray();
            
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signatureBytes);
            
            String currentSignature = bytesToHex(digest);
            return EXPECTED_SIGNATURE.equals(currentSignature);
            
        } catch (Exception e) {
            return false;
        }
    }
    
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}

// Usage
if (!AntiTamper.verifyAppIntegrity(this)) {
    Toast.makeText(this, "App tampered!", Toast.LENGTH_LONG).show();
    finish();
    return;
}
```

---

## Re-Test After Fixes

After implementing all fixes, re-run the tests:

```bash
python3 apk_login_tester.py TestApp_Fixed.apk
```

**Expected Results:**
- [ ] Decompilation still possible (normal)
- [ ] No hardcoded credentials found
- [ ] Direct activity launch blocked
- [ ] SharedPreferences modification ineffective
- [ ] Smali modification detected by anti-tampering
- [ ] Server verification required for login

**New Security Rating: A (Secure)**

---

## Key Takeaways

1. **Never trust client-side validation alone**
2. **Always verify with server**
3. **Store tokens securely (Keystore)**
4. **Enable code obfuscation**
5. **Add multiple layers of protection**
6. **Regularly test your app**

---

**Remember: Security is a process, not a product! 🔒**

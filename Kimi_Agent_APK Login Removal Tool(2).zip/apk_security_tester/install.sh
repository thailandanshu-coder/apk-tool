#!/bin/bash
# APK Security Tester - Installation Script
# ==========================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_banner() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║           APK Security Tester - Installer                    ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            echo "debian"
        elif [ -f /etc/redhat-release ]; then
            echo "redhat"
        else
            echo "linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    else
        echo "unknown"
    fi
}

install_debian() {
    echo -e "${GREEN}[+] Installing dependencies for Debian/Ubuntu...${NC}"
    
    sudo apt-get update
    sudo apt-get install -y \
        openjdk-11-jdk \
        python3 \
        python3-pip \
        android-tools-adb \
        unzip \
        wget
    
    install_apktool
    install_jadx
}

install_redhat() {
    echo -e "${GREEN}[+] Installing dependencies for RedHat/CentOS...${NC}"
    
    sudo yum install -y \
        java-11-openjdk-devel \
        python3 \
        python3-pip \
        android-tools \
        unzip \
        wget
    
    install_apktool
    install_jadx
}

install_macos() {
    echo -e "${GREEN}[+] Installing dependencies for macOS...${NC}"
    
    if ! command -v brew &> /dev/null; then
        echo -e "${YELLOW}[!] Homebrew not found. Installing...${NC}"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    
    brew install \
        openjdk@11 \
        python3 \
        android-platform-tools \
        unzip \
        wget
    
    install_apktool
    install_jadx
}

install_apktool() {
    echo -e "${GREEN}[+] Installing APKTool...${NC}"
    
    # Download apktool script
    sudo wget -q -O /usr/local/bin/apktool \
        https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool
    
    # Download apktool jar
    sudo wget -q -O /usr/local/bin/apktool.jar \
        https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar
    
    # Make executable
    sudo chmod +x /usr/local/bin/apktool
    
    echo -e "${GREEN}[+] APKTool installed!${NC}"
}

install_jadx() {
    echo -e "${GREEN}[+] Installing JADX...${NC}"
    
    # Create temp directory
    local tmpdir=$(mktemp -d)
    cd "$tmpdir"
    
    # Download and extract jadx
    wget -q \
        https://github.com/skylot/jadx/releases/download/v1.4.7/jadx-1.4.7.zip
    
    if [ -d "/opt/jadx" ]; then
        sudo rm -rf /opt/jadx
    fi
    
    sudo unzip -q jadx-1.4.7.zip -d /opt/jadx
    
    # Create symlink
    sudo ln -sf /opt/jadx/bin/jadx /usr/local/bin/jadx
    sudo ln -sf /opt/jadx/bin/jadx-gui /usr/local/bin/jadx-gui
    
    # Cleanup
    cd -
    rm -rf "$tmpdir"
    
    echo -e "${GREEN}[+] JADX installed!${NC}"
}

verify_installation() {
    echo -e "${GREEN}[+] Verifying installation...${NC}"
    
    local all_good=true
    
    echo ""
    echo "Checking tools:"
    
    for tool in apktool jadx java keytool adb python3; do
        if command -v $tool &> /dev/null; then
            local version=$(eval "$tool --version 2>/dev/null | head -1" || echo "installed")
            echo -e "  ✓ ${GREEN}$tool${NC}: $version"
        else
            echo -e "  ✗ ${RED}$tool${NC}: NOT FOUND"
            all_good=false
        fi
    done
    
    echo ""
    if [ "$all_good" = true ]; then
        echo -e "${GREEN}✓ All tools installed successfully!${NC}"
        return 0
    else
        echo -e "${RED}✗ Some tools are missing!${NC}"
        return 1
    fi
}

print_next_steps() {
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    Installation Complete!                    ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Read the guide:     cat README.md"
    echo "  2. Quick start:        cat QUICKSTART.md"
    echo "  3. Test your APK:      python3 apk_login_tester.py your_app.apk"
    echo ""
    echo "Example:"
    echo "  python3 apk_login_tester.py /home/user/myapp.apk"
    echo ""
}

main() {
    print_banner
    
    local os=$(detect_os)
    echo -e "${GREEN}[+] Detected OS: $os${NC}"
    
    case $os in
        debian)
            install_debian
            ;;
        redhat)
            install_redhat
            ;;
        macos)
            install_macos
            ;;
        *)
            echo -e "${RED}[!] Unsupported OS. Please install manually.${NC}"
            exit 1
            ;;
    esac
    
    verify_installation
    print_next_steps
}

main "$@"

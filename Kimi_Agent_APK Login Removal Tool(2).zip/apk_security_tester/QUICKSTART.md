# Quick Start Guide - APK Login Security Tester

## 5 Minute Mein Shuru Karein!

### Step 1: Tool Setup (2 minutes)

```bash
# Folder mein jao
cd apk_security_tester

# Script executable banao
chmod +x bypass_login.sh

# Check karo sab ready hai
python3 apk_login_tester.py --help
```

### Step 2: APK Test Karein (3 minutes)

```bash
# Apni APK ka test shuru karo
python3 apk_login_tester.py /path/to/your/app.apk
```

**Expected Output:**
```
[+] Decompiling app.apk...
[+] Analyzing login implementation...
[+] Checking vulnerabilities...
[+] Report generated: apk_test_workspace/security_report.txt
```

### Step 3: Report Padhein

```bash
cat apk_test_workspace/security_report.txt
```

## Common Commands Cheat Sheet

| Command | Kaam |
|---------|------|
| `python3 apk_login_tester.py app.apk` | Full security test |
| `./bypass_login.sh full-test app.apk` | Bash script se test |
| `apktool d app.apk -o out` | APK decompile |
| `apktool b out -o mod.apk` | APK recompile |
| `adb shell am start -n pkg/.Activity` | Activity launch |

## Login Bypass Karke Dekhein

### Method 1: Direct Activity Launch (Easiest)

```bash
# Package name find karo
aapt dump badging your_app.apk | grep package

# Output: package: name='com.yourapp' ...

# Main activity launch karo
adb shell am start -n com.yourapp/.MainActivity
```

**Agar app khul gayi bina login ke → BYPASS POSSIBLE! 🔴**

### Method 2: Smali Modify

```bash
# 1. Decompile
apktool d your_app.apk -o decompiled

# 2. Login activity dhoondo
grep -r "LoginActivity" decompiled/smali/ --include="*.smali"

# 3. Smali file mein ye dhoondo:
# if-eqz v0, :cond_login_failed

# 4. Change to:
# if-nez v0, :cond_login_failed

# 5. Recompile
apktool b decompiled -o mod_app.apk

# 6. Sign
./bypass_login.sh sign mod_app.apk

# 7. Install & test
adb install mod_app.apk
```

**Agar login skip ho gaya → BYPASS POSSIBLE! 🔴**

## Security Fix Quick Reference

| Problem | Quick Fix |
|---------|-----------|
| Hardcoded password | Server se verify karo |
| Local auth only | Server session use karo |
| No obfuscation | ProGuard enable karo |
| Debug enabled | `debuggable="false"` in manifest |
| Allow backup | `allowBackup="false"` in manifest |

## ProGuard Enable Karein (build.gradle)

```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

## Test Checklist

- [ ] APK decompile hota hai?
- [ ] Login smali code dikh raha hai?
- [ ] Direct activity launch se bypass hota hai?
- [ ] Smali modify se bypass hota hai?
- [ ] Hardcoded credentials hain?
- [ ] Debug mode on hai?
- [ ] Root detection hai?
- [ ] Certificate pinning hai?

## Agar Bypass Ho Gaya To Kya Karein?

### Immediate Actions:

1. **Server-side verification add karo**
   - Login hamesha server se verify karo
   - Local checks ko trust mat karo

2. **Obfuscation enable karo**
   - ProGuard/R8 on karo
   - Class names obfuscate karo

3. **Root detection add karo**
   - Rooted devices pe app band karo
   - Ya limited functionality do

4. **Anti-tampering add karo**
   - Signature verify karo runtime pe
   - Modified app detect karo

## Sample Secure Login Code

```java
public class SecureLogin {
    
    // Server se verify karo
    public void login(String username, String password) {
        // 1. Input validation
        if (!isValidInput(username, password)) {
            showError("Invalid input");
            return;
        }
        
        // 2. Server verification
        api.login(username, password).enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Response<AuthResponse> response) {
                if (response.isSuccessful() && response.body().isValid()) {
                    // 3. Secure token storage
                    saveTokenSecurely(response.body().getToken());
                    navigateToMain();
                } else {
                    showError("Invalid credentials");
                }
            }
            
            @Override
            public void onFailure(Throwable t) {
                showError("Network error");
            }
        });
    }
    
    // Token ko secure store karo
    private void saveTokenSecurely(String token) {
        // Use Android Keystore
        // NOT SharedPreferences
    }
}
```

## Emergency Contacts

Agar kuch samajh nahi aaya:
- README.md padho (detailed guide)
- Error message Google karo
- Stack Overflow check karo

---

**Ready to test? Chaliye shuru karte hain! 🚀**

#!/usr/bin/env python3
"""
ZIP Extractor - Advance Version
===============================
Direct bypass and extract - NO password guessing
Simple: ZIP → Extract → Folder

Usage:
  python3 zip_extractor.py your_file.zip
  python3 zip_extractor.py your_file.zip -p yourpassword

Use ONLY on ZIP files you own/created!
"""

import zipfile
import os
import sys
import argparse
from datetime import datetime

class ZIPExtractor:
    def __init__(self, zip_path, password=None):
        self.zip_path = os.path.abspath(zip_path)
        self.zip_name = os.path.basename(zip_path)
        self.password = password
        
        # Output folder
        base_name = os.path.splitext(self.zip_name)[0]
        dir_name = os.path.dirname(self.zip_path)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = os.path.join(dir_name, f"{base_name}_EXTRACTED_{timestamp}")
        
    def print_banner(self):
        print("""
╔════════════════════════════════════════════════════════════════╗
║                    ZIP EXTRACTOR                               ║
║              Direct Bypass → Extract → Folder                  ║
╚════════════════════════════════════════════════════════════════╝
""")
        
    def format_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"
        
    def check_zip(self):
        if not os.path.exists(self.zip_path):
            print(f"✗ File not found: {self.zip_path}")
            return False
            
        try:
            with zipfile.ZipFile(self.zip_path, 'r') as zf:
                self.total_files = len(zf.namelist())
                self.total_size = sum(z.file_size for z in zf.infolist())
                
                # Check if password protected
                try:
                    zf.testzip()
                    self.is_encrypted = False
                except RuntimeError:
                    self.is_encrypted = True
                    
                return True
        except Exception as e:
            print(f"✗ Invalid ZIP: {e}")
            return False
            
    def ask_password(self):
        print(f"\n🔒 This ZIP is password protected")
        print(f"   Enter the password to extract:\n")
        self.password = input("   Password: ")
        if not self.password:
            print("✗ No password entered")
            return False
        return True
        
    def extract(self):
        print(f"\n[+] Extracting files...")
        print(f"   To: {self.output_dir}\n")
        
        os.makedirs(self.output_dir, exist_ok=True)
        
        try:
            with zipfile.ZipFile(self.zip_path, 'r') as zf:
                files = zf.namelist()
                total = len(files)
                
                for i, file_path in enumerate(files, 1):
                    # Progress
                    percent = int((i / total) * 100)
                    bar = '█' * int(percent / 2.5) + '░' * (40 - int(percent / 2.5))
                    print(f"\r   |{bar}| {percent}% ({i}/{total})", end='', flush=True)
                    
                    # Extract
                    pwd = self.password.encode() if self.password else None
                    zf.extract(file_path, path=self.output_dir, pwd=pwd)
                    
                print()  # New line after progress
                return True
                
        except RuntimeError:
            print(f"\n✗ Wrong password!")
            return False
        except Exception as e:
            print(f"\n✗ Error: {e}")
            return False
            
    def show_result(self):
        # Count extracted files
        file_count = 0
        for root, dirs, files in os.walk(self.output_dir):
            file_count += len(files)
            
        print(f"\n" + "=" * 60)
        print("✅ EXTRACTION COMPLETE!")
        print("=" * 60)
        print(f"\n📦 Original: {self.zip_path}")
        print(f"📁 Extracted: {self.output_dir}")
        print(f"📊 Files: {file_count}")
        print(f"\n✨ Files ready - No password needed!")
        print("=" * 60)
        
    def run(self):
        self.print_banner()
        
        # Check ZIP
        if not self.check_zip():
            return False
            
        # Show info
        print(f"[+] ZIP Info:")
        print(f"   Name: {self.zip_name}")
        print(f"   Files: {self.total_files}")
        print(f"   Size: {self.format_size(self.total_size)}")
        
        # Get password if needed
        if self.is_encrypted and not self.password:
            if not self.ask_password():
                return False
                
        # Extract
        if self.extract():
            self.show_result()
            return True
        return False


def main():
    parser = argparse.ArgumentParser(
        description='ZIP Extractor - Direct bypass and extract',
        epilog="""
Examples:
  python3 zip_extractor.py file.zip
  python3 zip_extractor.py file.zip -p mypassword

⚠️ Use only on ZIP files you own/created!
        """
    )
    parser.add_argument('zip', help='ZIP file to extract')
    parser.add_argument('-p', '--password', help='ZIP password')
    
    args = parser.parse_args()
    
    extractor = ZIPExtractor(args.zip, args.password)
    if extractor.run():
        print("\n✅ Done!")
    else:
        print("\n❌ Failed!")
        sys.exit(1)


if __name__ == '__main__':
    main()

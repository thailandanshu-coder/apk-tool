#!/usr/bin/env python3
"""
ZIP Extractor Web - Advance Version
===================================
Simple web interface for extracting ZIP files
NO password guessing - Direct extract only
"""

import zipfile
import os
import json
from datetime import datetime
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import cgi

# Directories
WORK_DIR = '/tmp/ZIP-Extractor-Advance'
UPLOADS_DIR = os.path.join(WORK_DIR, 'uploads')
EXTRACTED_DIR = os.path.join(WORK_DIR, 'extracted')
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(EXTRACTED_DIR, exist_ok=True)

# Jobs storage
jobs = {}

# HTML Page
HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔓 ZIP Extractor</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            color: #fff;
            padding: 20px;
        }
        .container { max-width: 700px; margin: 0 auto; }
        
        header {
            text-align: center;
            padding: 40px 0 30px;
            border-bottom: 2px solid #e94560;
            margin-bottom: 30px;
        }
        header h1 { 
            font-size: 2.5em; 
            color: #e94560; 
            margin-bottom: 10px;
        }
        header p { color: #888; }
        
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .upload-area {
            border: 3px dashed #e94560;
            border-radius: 15px;
            padding: 50px 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: rgba(233, 69, 96, 0.05);
        }
        .upload-area:hover {
            background: rgba(233, 69, 96, 0.15);
        }
        .upload-area input { display: none; }
        .upload-icon { font-size: 4em; margin-bottom: 15px; }
        
        .input-field {
            width: 100%;
            padding: 15px 20px;
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 10px;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 1em;
            margin: 15px 0;
        }
        .input-field::placeholder { color: #666; }
        
        .btn {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #e94560, #ff6b6b);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.2em;
            font-weight: bold;
        }
        .btn:hover { opacity: 0.9; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        
        .progress-container {
            background: rgba(0,0,0,0.3);
            border-radius: 10px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-bar {
            background: linear-gradient(90deg, #e94560, #ff6b6b);
            height: 40px;
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .success-box {
            background: rgba(40, 167, 69, 0.2);
            border: 2px solid #28a745;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
        }
        .success-box h2 { color: #28a745; margin-bottom: 15px; }
        
        .download-btn {
            display: inline-block;
            padding: 15px 40px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: bold;
            margin: 15px 0;
        }
        
        .error-box {
            background: rgba(220, 53, 69, 0.2);
            border: 2px solid #dc3545;
            padding: 20px;
            border-radius: 15px;
            color: #ff6b6b;
            text-align: center;
        }
        
        .warning {
            background: rgba(255, 193, 7, 0.15);
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            color: #ffc107;
        }
        
        .hidden { display: none !important; }
        
        footer {
            text-align: center;
            padding: 30px 0;
            color: #666;
            border-top: 1px solid #333;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🔓 ZIP Extractor</h1>
            <p>Extract password-protected ZIP files</p>
        </header>
        
        <div class="warning">
            ⚠️ Use this tool ONLY on ZIP files you own/created!
        </div>
        
        <!-- Upload Section -->
        <div id="uploadSection" class="card">
            <form id="form" enctype="multipart/form-data">
                <label class="upload-area" onclick="document.getElementById('file').click()">
                    <input type="file" id="file" name="zip" accept=".zip" required>
                    <div class="upload-icon">📦</div>
                    <div style="font-size: 1.2em;">Click to select ZIP file</div>
                    <div id="filename" style="color: #e94560; margin-top: 10px;"></div>
                </label>
                
                <input type="password" id="pwd" class="input-field" placeholder="Enter ZIP password (if protected)">
                
                <button type="submit" class="btn" id="submitBtn">🚀 Extract Files</button>
            </form>
        </div>
        
        <!-- Progress Section -->
        <div id="progressSection" class="card hidden">
            <h3 style="color: #e94560; margin-bottom: 15px;">⏳ Extracting...</h3>
            <div class="progress-container">
                <div class="progress-bar" id="bar" style="width: 0%">0%</div>
            </div>
        </div>
        
        <!-- Success Section -->
        <div id="successSection" class="hidden">
            <div class="card success-box">
                <h2>✅ Extraction Complete!</h2>
                <p id="details"></p>
                <a href="#" id="downloadLink" class="download-btn">📥 Download Files</a>
            </div>
            <div class="card" style="text-align: center;">
                <button class="btn" onclick="location.reload()" style="width: auto; padding: 15px 40px;">🔄 Extract Another</button>
            </div>
        </div>
        
        <!-- Error Section -->
        <div id="errorSection" class="card hidden">
            <div class="error-box">
                <h3 style="margin-bottom: 10px;">❌ Extraction Failed</h3>
                <p id="errorMsg"></p>
                <button class="btn" onclick="location.reload()" style="margin-top: 15px; width: auto;">Try Again</button>
            </div>
        </div>
        
        <footer>
            <p>ZIP Extractor - For educational use only</p>
        </footer>
    </div>
    
    <script>
        let jobId = null;
        
        document.getElementById('file').onchange = function() {
            document.getElementById('filename').textContent = this.files[0] ? this.files[0].name : '';
        };
        
        document.getElementById('form').onsubmit = function(e) {
            e.preventDefault();
            
            const f = new FormData();
            f.append('zip', document.getElementById('file').files[0]);
            f.append('password', document.getElementById('pwd').value);
            
            document.getElementById('uploadSection').classList.add('hidden');
            document.getElementById('progressSection').classList.remove('hidden');
            document.getElementById('submitBtn').disabled = true;
            
            fetch('/extract', {method: 'POST', body: f})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    jobId = d.job_id;
                    poll();
                } else {
                    showError(d.error);
                }
            });
        };
        
        function poll() {
            fetch('/status/' + jobId).then(r => r.json()).then(d => {
                document.getElementById('bar').style.width = d.progress + '%';
                document.getElementById('bar').textContent = d.progress + '%';
                
                if(d.status === 'completed') {
                    document.getElementById('progressSection').classList.add('hidden');
                    document.getElementById('successSection').classList.remove('hidden');
                    document.getElementById('details').textContent = d.files_extracted + ' files extracted';
                    document.getElementById('downloadLink').href = '/download/' + jobId;
                } else if(d.status === 'error') {
                    showError(d.error);
                } else {
                    setTimeout(poll, 500);
                }
            });
        }
        
        function showError(msg) {
            document.getElementById('progressSection').classList.add('hidden');
            document.getElementById('errorSection').classList.remove('hidden');
            document.getElementById('errorMsg').textContent = msg;
        }
    </script>
</body>
</html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML.encode())
            
        elif self.path.startswith('/status/'):
            jid = self.path.split('/')[-1]
            if jid in jobs:
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(jobs[jid]).encode())
            else:
                self.send_response(404)
                self.end_headers()
                
        elif self.path.startswith('/download/'):
            jid = self.path.split('/')[-1]
            if jid in jobs and jobs[jid]['status'] == 'completed':
                dl_zip = os.path.join(EXTRACTED_DIR, jid + '_download.zip')
                with zipfile.ZipFile(dl_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for root, dirs, files in os.walk(jobs[jid]['output_dir']):
                        for f in files:
                            fp = os.path.join(root, f)
                            zf.write(fp, os.path.relpath(fp, jobs[jid]['output_dir']))
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Disposition', 'attachment; filename=extracted.zip')
                self.end_headers()
                with open(dl_zip, 'rb') as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_POST(self):
        if self.path == '/extract':
            form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={'REQUEST_METHOD': 'POST'})
            
            if 'zip' not in form:
                self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False, 'error': 'No ZIP file'}).encode())
                return
            
            job_id = 'job_' + datetime.now().strftime('%Y%m%d_%H%M%S')
            zip_path = os.path.join(UPLOADS_DIR, job_id + '.zip')
            output_dir = os.path.join(EXTRACTED_DIR, job_id)
            
            with open(zip_path, 'wb') as f:
                f.write(form['zip'].file.read())
            
            password = form.getvalue('password', '')
            
            jobs[job_id] = {
                'job_id': job_id,
                'status': 'extracting',
                'progress': 0,
                'files_extracted': 0,
                'output_dir': output_dir
            }
            
            def extract():
                try:
                    os.makedirs(output_dir, exist_ok=True)
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        files = zf.namelist()
                        for i, f in enumerate(files):
                            try:
                                pwd = password.encode() if password else None
                                zf.extract(f, path=output_dir, pwd=pwd)
                                jobs[job_id]['files_extracted'] += 1
                                jobs[job_id]['progress'] = int((i + 1) / len(files) * 100)
                            except:
                                pass
                    jobs[job_id]['status'] = 'completed'
                except RuntimeError:
                    jobs[job_id]['status'] = 'error'
                    jobs[job_id]['error'] = 'Wrong password! Please enter the correct password.'
                except Exception as e:
                    jobs[job_id]['status'] = 'error'
                    jobs[job_id]['error'] = str(e)
            
            threading.Thread(target=extract, daemon=True).start()
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'success': True, 'job_id': job_id}).encode())
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == '__main__':
    print('=' * 60)
    print('🔓 ZIP Extractor Web')
    print('=' * 60)
    print('URL: http://localhost:9999')
    print('=' * 60)
    HTTPServer(('0.0.0.0', 9999), Handler).serve_forever()

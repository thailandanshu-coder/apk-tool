# APK Login Page Remover

> **Remove login page from your APK files automatically!**

---

## 🎯 What This Tool Does

This tool removes the login page from APK files by:
1. Decompiling the APK
2. Disabling login activities in AndroidManifest.xml
3. Modifying smali code to bypass login checks
4. Recompiling and signing the APK

**Result:** APK without login page!

---

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y openjdk-11-jdk

# Install APKTool
wget https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool
wget https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.1.jar
sudo mv apktool /usr/local/bin/
sudo mv apktool_*.jar /usr/local/bin/apktool.jar
sudo chmod +x /usr/local/bin/apktool

# Verify
apktool --version
```

### Step 2: Run The Tool

```bash
python3 apk_login_remover.py /path/to/your_app.apk
```

### Step 3: Get Output

```
login_removed_your_app/
├── your_app_no_login.apk    ← Modified APK (login removed!)
├── decompiled/              ← Source code
└── test.keystore            ← Signing key
```

---

## 📋 Example Output

```
╔══════════════════════════════════════════════════════════════╗
║              APK LOGIN PAGE REMOVER                          ║
╚══════════════════════════════════════════════════════════════╝

[+] Checking dependencies...
  ✓ apktool found
  ✓ java found
  ✓ keytool found
  ✓ jarsigner found

[+] Decompiling myapp.apk...
  ✓ Decompiled to: login_removed_myapp/decompiled

[+] Package: com.example.myapp
[+] Login activities found: 2
    - com.example.myapp.LoginActivity
    - com.example.myapp.SplashActivity

[+] Modifying AndroidManifest.xml...
  ✓ Disabled: com.example.myapp.LoginActivity
  ✓ Disabled: com.example.myapp.SplashActivity

[+] Modifying smali code...
  ✓ Modified: LoginActivity.smali
  ✓ Modified: SplashActivity.smali

[+] Recompiling APK...
  ✓ Recompiled: login_removed_myapp/myapp_no_login.apk

[+] Creating keystore...
  ✓ Keystore created

[+] Signing APK...
  ✓ APK signed

[+] Verifying APK...
  ✓ APK created: 15.23 MB

============================================================
✅ LOGIN REMOVED SUCCESSFULLY!
============================================================

📦 Original APK: /path/to/myapp.apk
📦 Modified APK: login_removed_myapp/myapp_no_login.apk

✨ Login has been removed!

📁 Source code: login_removed_myapp/decompiled

⚠️  Install with:
   adb install "login_removed_myapp/myapp_no_login.apk"
============================================================
```

---

## 🔧 How It Works

### Method 1: AndroidManifest.xml
- Disables login activities
- Sets main activity as launcher

### Method 2: Smali Code
- Modifies login check conditions
- Bypasses authentication logic

---

## ⚠️ Important

**This tool is for your own APKs only!**

- ✅ Removing login from your own app → ALLOWED
- ❌ Modifying someone else's app → ILLEGAL

---

## 🆘 Troubleshooting

### "apktool: command not found"
```bash
# Install APKTool
wget https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/linux/apktool
sudo mv apktool /usr/local/bin/
sudo chmod +x /usr/local/bin/apktool
```

### "java: command not found"
```bash
sudo apt install openjdk-11-jdk
```

### "App crashes after modification"
- Some apps have anti-tampering protection
- Try different modification methods

---

## 📁 Files

| File | Description |
|------|-------------|
| `apk_login_remover.py` | Main tool |
| `README.md` | This file |

---

**Ready to remove login from your APK? Let's go! 🚀**
